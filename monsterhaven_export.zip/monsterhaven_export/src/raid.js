/* MONSTERHAVEN raiding: send a squad to a territory, auto-resolve combat, bring back loot and captives. */
(function () {
  "use strict";
  var MH = window.MH, C = MH.C, S = MH.Sim, W = MH.World;
  var Raid = MH.Raid = {};

  function R() { return Math.random(); }
  function rint(a, b) { return a + Math.floor(R() * (b - a + 1)); }

  Raid.terrFor = function (id) { return C.TERR.filter(function (t) { return t.id === id; })[0]; };
  Raid.unlocked = function (t) {
    var G = S.G;
    if (t.castle > G.castle) return false;
    if (t.gate && !S.D.cnt[t.gate]) return false;
    return true;
  };
  Raid.squadPower = function (ids) { return ids.reduce(function (a, id) { var m = S.ent(id); return a + (m ? S.power(m) : 0); }, 0); };

  Raid.canSend = function (ids, terr) {
    if (!ids.length) return S.msg(false, "Pick at least one monster");
    if (ids.length > S.D.squadCap) return S.msg(false, "Squad limit is " + S.D.squadCap);
    if (!Raid.unlocked(terr)) return S.msg(false, "Not unlocked yet");
    for (var i = 0; i < ids.length; i++) { var m = S.ent(ids[i]); if (!m || m.away) return S.msg(false, "A monster is unavailable"); }
    return { ok: true };
  };

  Raid.send = function (ids, terrId) {
    var terr = Raid.terrFor(terrId), chk = Raid.canSend(ids, terr); if (!chk.ok) return chk;
    var G = S.G;
    ids.forEach(function (id) { var m = S.ent(id); m.away = true; m.st = "toGate"; m.path = null; S.unassign(m); });
    var exp = { id: G.nid++, terr: terrId, squad: ids.slice(), left: terr.travel, phase: "out" };
    G.exps.push(exp);
    S.addLog("A squad of " + ids.length + " set out for the " + terr.name + ".");
    return { ok: true, exp: exp };
  };
  Raid.recall = function (expId) {
    var exp = S.G.exps.filter(function (e) { return e.id === expId; })[0];
    if (!exp || exp.phase !== "out") return S.msg(false, "Can't recall now");
    exp.phase = "return"; exp.left = Math.max(10, exp.left * 0.6);
    S.addLog("The squad was recalled early.");
    return { ok: true };
  };

  function resolve(exp) {
    var terr = Raid.terrFor(exp.terr), G = S.G, squad = exp.squad.map(S.ent).filter(Boolean);
    var power = squad.reduce(function (a, m) { return a + S.power(m); }, 0) * (0.92 + R() * 0.16);
    var ratio = power / terr.str, winChance = Math.min(0.96, Math.max(0.04, 0.5 + (ratio - 1) * 0.7));
    var win = R() < winChance;
    var rounds = [], hpLeft = {}; squad.forEach(function (m) { hpLeft[m.id] = 1; });
    var enemyHp = 1, rn = 0;
    while (rn < 6 && enemyHp > 0 && squad.some(function (m) { return hpLeft[m.id] > 0; })) {
      rn++;
      var dmg = 0; squad.forEach(function (m) { if (hpLeft[m.id] > 0) dmg += S.stat(m, "atk"); });
      var scaledDmg = dmg / (terr.str * 0.3);
      enemyHp -= scaledDmg * (0.85 + R() * 0.3);
      var inc = (terr.str * 0.22) / Math.max(1, squad.length) / 120;
      squad.forEach(function (m) { if (hpLeft[m.id] > 0) { var def = S.stat(m, "def"); hpLeft[m.id] -= inc / (1 + def * 0.05) * (0.8 + R() * 0.5); } });
      rounds.push({ n: rn, dmg: Math.round(dmg) });
      if (!win && rn >= 3) break;
    }
    var casualties = [], xpEach = win ? 18 + terr.tier * 6 : 6;
    squad.forEach(function (m) {
      var hurt = clampF(1 - Math.max(0, hpLeft[m.id]), 0, 0.95);
      if (!win) hurt = Math.max(hurt, 0.3 + R() * 0.4);
      m.hpf = clampF(1 - hurt, 0.08, 1);
      S.addXp(m, xpEach);
      if (win && R() < 0.015 * terr.tier) casualties.push(m.name);
    });
    var rewards = {}, captives = [];
    if (win) {
      for (var k in terr.rew) { var r = terr.rew[k]; rewards[k] = rint(r[0], r[1]); }
      var freeCells = S.D.prisonCap - G.humans.length;
      var nCap = Math.min(terr.cap.max, freeCells, rint(0, terr.cap.max));
      for (var i = 0; i < nCap; i++) {
        var occ = terr.cap.types[Math.min(i, terr.cap.types.length - 1)];
        var boost = terr.cap.rar + terr.tier * 0.15;
        var h = S.newHuman(occ, boost);
        captives.push(h); G.stats.captured++;
        if (occ === "adventurer") G.stats.adventurers++;
      }
      if (R() < terr.equip) {
        var slot = R() < 0.5 ? "weapon" : "armor", tier = Math.min(5, 1 + Math.floor(terr.tier / 2));
        var it = S.makeItem(slot, tier, R() < 0.2 ? 2 : R() < 0.5 ? 1 : 0);
        G.items.push(it); rewards._item = it.name;
      }
      S.gain(rewards);
      G.stats.wins++;
    }
    G.stats.raids++;
    var report = { id: G.nid++, terr: terr.name, win: win, rewards: rewards, captives: captives.map(function (h) { return { name: h.name, occ: C.HUMAN[h.occ].name, rar: h.rar }; }),
      squad: squad.map(function (m) { return { name: m.name, hp: Math.round(m.hpf * 100) }; }), casualties: casualties, t: Math.round(G.time), read: false };
    G.reports.unshift(report); if (G.reports.length > 20) G.reports.length = 20;
    casualties.forEach(function (name) { G.monsters = G.monsters.filter(function (m) { return m.name !== name; }); });
    squad.forEach(function (m) {
      if (G.monsters.indexOf(m) >= 0) {
        m.away = false; m.path = null;
        var g = W.gateTile(); m.px = g[0] + 0.5; m.py = g[1] + 0.5;
        m.st = "idle"; m.wait = 0;
      }
    });
    S.addLog((win ? "Victory at the " : "Defeat at the ") + terr.name + ".", win ? "good" : "bad");
    return report;
  }
  function clampF(v, a, b) { return Math.max(a, Math.min(b, v)); }

  Raid.tick = function (offline) {
    var G = S.G, keep = [];
    G.exps.forEach(function (exp) {
      exp.left -= offline ? 30 : (1 / 60);
      if (exp.phase === "out" && exp.left <= 0) {
        resolve(exp);
      } else keep.push(exp);
    });
    G.exps = keep;
  };
})();
