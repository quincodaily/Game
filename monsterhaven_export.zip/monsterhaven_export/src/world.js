/* MONSTERHAVEN world: terrain, occupancy grid, placement rules, A* pathfinding. */
(function () {
  "use strict";
  var MH = window.MH, C = MH.C, Art = MH.Art;
  var W = C.W, H = C.H;
  var T = { GRASS: 0, WATER: 1, TREE: 2, ROCK: 3, ROAD: 4, BRIDGE: 5, WALL: 6, GATE: 7, DECOR: 8 };
  var Wd = MH.World = { T: T, bounds: null, gateX: 31, corners: [] };
  Wd.base = new Uint8Array(W * H);
  Wd.terrain = new Uint8Array(W * H);
  Wd.occ = new Int32Array(W * H);
  Wd.version = 0;                // bumps whenever blocking changes, so walkers can re-path

  Wd.gen = function (seed) {
    var R = Art.rng(seed || 1337), base = Wd.base, i, x, y;
    base.fill(T.GRASS);
    for (y = 0; y < H; y++) {
      var cx = Math.round(8 + 3 * Math.sin(y / 6));
      for (x = cx - 1; x <= cx + 1; x++) base[y * W + x] = T.WATER;
      if (y === 27 || y === 28) for (x = cx - 1; x <= cx + 1; x++) base[y * W + x] = T.BRIDGE;
    }
    for (x = 13; x <= 52; x++) if (base[25 * W + x] === T.GRASS) base[25 * W + x] = T.ROAD;
    for (y = 22; y < H; y++) if (base[y * W + 31] === T.GRASS) base[y * W + 31] = T.ROAD;
    for (x = 9; x <= 13; x++) { var by = x < 12 ? 27 : 27; if (base[by * W + x] === T.GRASS) base[by * W + x] = T.ROAD; }
    for (y = 0; y < H; y++) for (x = 0; x < W; x++) {
      if (base[y * W + x] !== T.GRASS) continue;
      var r = R(), inCore = x >= 16 && x <= 46 && y >= 12 && y <= 34;
      var forest = x >= 44 && x <= 52 && y >= 26 && y <= 36, hills = x >= 44 && x <= 52 && y >= 10 && y <= 18;
      var outside = x < 13 || x > 50 || y < 9 || y > 38;
      if (forest) { if (r < 0.24) base[y * W + x] = T.TREE; }
      else if (hills) { if (r < 0.16) base[y * W + x] = T.ROCK; }
      else if (outside) { if (r < 0.2) base[y * W + x] = T.TREE; else if (r < 0.25) base[y * W + x] = T.ROCK; }
      else if (inCore) { if (r < 0.012) base[y * W + x] = T.TREE; }
      else { if (r < 0.05) base[y * W + x] = T.TREE; else if (r < 0.065) base[y * W + x] = T.ROCK; }
    }
    /* keep the castle plaza and the prebuilt lots clear */
    for (y = 14; y <= 30; y++) for (x = 18; x <= 44; x++) if (base[y * W + x] === T.TREE || base[y * W + x] === T.ROCK) base[y * W + x] = T.GRASS;
    for (y = 25; y <= 33; y++) for (x = 40; x <= 48; x++) if (base[y * W + x] === T.TREE && R() < 0.5) base[y * W + x] = T.GRASS;
  };

  Wd.boundsFor = function (level) {
    var ix = Math.max(4, 12 - 2 * (level - 1)), iy = Math.max(3, 8 - (level - 1));
    return { x0: ix, y0: iy, x1: W - 1 - ix, y1: H - 1 - iy };
  };

  Wd.setBounds = function (level) {
    var b = Wd.bounds = Wd.boundsFor(level), x, y;
    Wd.terrain.set(Wd.base);
    for (x = b.x0; x <= b.x1; x++) { Wd.terrain[b.y0 * W + x] = T.WALL; Wd.terrain[b.y1 * W + x] = T.WALL; }
    for (y = b.y0; y <= b.y1; y++) { Wd.terrain[y * W + b.x0] = T.WALL; Wd.terrain[y * W + b.x1] = T.WALL; }
    for (x = Wd.gateX - 1; x <= Wd.gateX + 1; x++) Wd.terrain[b.y1 * W + x] = T.GATE;
    Wd.corners = [[b.x0 + 1, b.y0 + 1], [b.x1 - 2, b.y0 + 1]];
    Wd.corners.forEach(function (c) { for (var yy = 0; yy < 2; yy++) for (var xx = 0; xx < 2; xx++) Wd.terrain[(c[1] + yy) * W + c[0] + xx] = T.DECOR; });
    Wd.version++;
    Wd.layer = null;
  };

  Wd.size = function (type, rot) { return Art.size(type, rot); };

  Wd.rebuildOcc = function (buildings) {
    Wd.occ.fill(0);
    buildings.forEach(function (b) {
      var s = Wd.size(b.type, b.rot);
      for (var y = 0; y < s[1]; y++) for (var x = 0; x < s[0]; x++) Wd.occ[(b.y + y) * W + b.x + x] = b.id;
    });
    Wd.version++;
  };

  function walkTerrain(t) { return t === T.GRASS || t === T.ROAD || t === T.BRIDGE || t === T.GATE; }
  Wd.walkable = function (x, y) {
    if (x < 0 || y < 0 || x >= W || y >= H) return false;
    var b = Wd.bounds;
    if (x < b.x0 || x > b.x1 || y < b.y0 || y > b.y1) return false;
    return walkTerrain(Wd.terrain[y * W + x]) && Wd.occ[y * W + x] === 0;
  };

  Wd.nearestWalkable = function (x, y, maxR) {
    if (Wd.walkable(x, y)) return [x, y];
    for (var r = 1; r <= (maxR || 8); r++) {
      for (var dy = -r; dy <= r; dy++) for (var dx = -r; dx <= r; dx++) {
        if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
        if (Wd.walkable(x + dx, y + dy)) return [x + dx, y + dy];
      }
    }
    return null;
  };

  /* door = the tile just south of the footprint's middle, snapped to something walkable */
  Wd.doorTile = function (b) {
    var s = Wd.size(b.type, b.rot);
    return Wd.nearestWalkable(b.x + Math.floor(s[0] / 2), b.y + s[1], 6) || [Wd.gateX, Wd.bounds.y1 - 2];
  };
  Wd.gateTile = function () { return Wd.nearestWalkable(Wd.gateX, Wd.bounds.y1, 3) || [Wd.gateX, Wd.bounds.y1]; };

  /* returns {ok, reason} */
  Wd.canPlace = function (type, x, y, rot, ignoreId) {
    var s = Wd.size(type, rot), b = Wd.bounds;
    if (x < b.x0 + 1 || y < b.y0 + 1 || x + s[0] - 1 > b.x1 - 1 || y + s[1] - 1 > b.y1 - 2) return { ok: false, reason: "Outside the village" };
    for (var j = 0; j < s[1]; j++) for (var i = 0; i < s[0]; i++) {
      var idx = (y + j) * W + x + i, t = Wd.terrain[idx];
      if (t !== T.GRASS && t !== T.ROAD) return { ok: false, reason: "Blocked by terrain" };
      if (Wd.occ[idx] !== 0 && Wd.occ[idx] !== ignoreId) return { ok: false, reason: "Overlaps a building" };
    }
    var dx = x + Math.floor(s[0] / 2), dy = y + s[1];
    var dt = Wd.terrain[dy * W + dx];
    if (!walkTerrain(dt) || (Wd.occ[dy * W + dx] !== 0 && Wd.occ[dy * W + dx] !== ignoreId)) return { ok: false, reason: "Entrance is blocked" };
    return { ok: true };
  };

  /* ---------- A* ---------- */
  var gS = new Float32Array(W * H), came = new Int32Array(W * H), seen = new Int32Array(W * H), closed = new Int32Array(W * H), stamp = 0;
  var heap = [], hf = [];
  function hpush(i, f) { heap.push(i); hf.push(f); var k = heap.length - 1; while (k > 0) { var p = (k - 1) >> 1; if (hf[p] <= hf[k]) break; var ti = heap[p], tf = hf[p]; heap[p] = heap[k]; hf[p] = hf[k]; heap[k] = ti; hf[k] = tf; k = p; } }
  function hpop() {
    var top = heap[0], li = heap.pop(), lf = hf.pop();
    if (heap.length) {
      heap[0] = li; hf[0] = lf; var k = 0, n = heap.length;
      for (;;) { var l = 2 * k + 1, r = l + 1, m = k; if (l < n && hf[l] < hf[m]) m = l; if (r < n && hf[r] < hf[m]) m = r; if (m === k) break; var ti = heap[m], tf = hf[m]; heap[m] = heap[k]; hf[m] = hf[k]; heap[k] = ti; hf[k] = tf; k = m; }
    }
    return top;
  }

  /* returns array of [x,y] excluding the start, or null */
  Wd.path = function (sx, sy, tx, ty) {
    if (!Wd.walkable(tx, ty)) { var nt = Wd.nearestWalkable(tx, ty, 6); if (!nt) return null; tx = nt[0]; ty = nt[1]; }
    if (sx === tx && sy === ty) return [];
    stamp++; heap.length = 0; hf.length = 0;
    var s = sy * W + sx, goal = ty * W + tx, n = 0;
    gS[s] = 0; seen[s] = stamp; came[s] = -1;
    hpush(s, 0);
    while (heap.length && n++ < 9000) {
      var cur = hpop();
      if (closed[cur] === stamp) continue;
      closed[cur] = stamp;
      if (cur === goal) {
        var out = [], k = cur;
        while (k !== s) { out.push([k % W, (k / W) | 0]); k = came[k]; }
        return out.reverse();
      }
      var cx = cur % W, cy = (cur / W) | 0;
      for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) {
        if (!dx && !dy) continue;
        var nx = cx + dx, ny = cy + dy;
        if (!Wd.walkable(nx, ny)) continue;
        if (dx && dy && (!Wd.walkable(cx + dx, cy) || !Wd.walkable(cx, cy + dy))) continue;
        var ni = ny * W + nx, ng = gS[cur] + (dx && dy ? 1.414 : 1);
        if (seen[ni] === stamp && ng >= gS[ni]) continue;
        seen[ni] = stamp; gS[ni] = ng; came[ni] = cur;
        var ddx = Math.abs(nx - tx), ddy = Math.abs(ny - ty);
        hpush(ni, ng + (ddx + ddy) + (1.414 - 2) * Math.min(ddx, ddy));
      }
    }
    return null;
  };
})();
