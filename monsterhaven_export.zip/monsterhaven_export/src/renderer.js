/* MONSTERHAVEN renderer: camera (drag to pan, wheel/pinch to zoom), draws terrain, camps, buildings, NPCs. */
(function () {
  "use strict";
  var MH = window.MH, C = MH.C, W = MH.World, S = MH.Sim, Art = MH.Art, AI = MH.AI;
  var Rd = MH.Renderer = {};
  var TS = C.TILE, MAPW = C.W * TS, MAPH = C.H * TS;

  var cv, ctx, dpr = 1, vw = 0, vh = 0, terrain = null, terrVer = -1;
  var cam = { x: MAPW * 0.48, y: MAPH * 0.52, z: 2 };
  var minZ = 0.9, maxZ = 4.2;
  var reduceMotion = !!(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
  var pointers = {}, dragging = false, dragMoved = 0, pinchD0 = 0, pinchZ0 = 1, lastTap = 0;
  var selection = null;          // {type:'bld'|'ent', id}
  var placeMode = null;          // {type, rot}
  var onTap = null, onPlace = null, onLongTap = null;
  var camps = {};                // id -> {x,y}

  Rd.init = function (canvas) {
    cv = canvas; ctx = cv.getContext("2d");
    C.TERR.forEach(function (t) { camps[t.id] = { x: t.pos[0] * TS + TS / 2, y: t.pos[1] * TS + TS }; });
    resize();
    window.addEventListener("resize", resize);
    cv.addEventListener("pointerdown", onDown);
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    window.addEventListener("pointercancel", onUp);
    cv.addEventListener("wheel", onWheel, { passive: false });
    cv.addEventListener("contextmenu", function (e) { e.preventDefault(); });
  };

  function resize() {
    var r = cv.getBoundingClientRect();
    dpr = Math.min(2, window.devicePixelRatio || 1);
    vw = r.width; vh = r.height;
    cv.width = Math.round(vw * dpr); cv.height = Math.round(vh * dpr);
  }
  Rd.resize = resize;

  Rd.setHandlers = function (h) { onTap = h.tap; onPlace = h.place; onLongTap = h.longTap; };
  Rd.setSelection = function (s) { selection = s; };
  Rd.getSelection = function () { return selection; };
  Rd.setPlaceMode = function (p) { placeMode = p; };
  Rd.getPlaceMode = function () { return placeMode; };

  function clampCam() {
    var halfW = vw / 2 / cam.z, halfH = vh / 2 / cam.z;
    var pad = TS * 6;
    cam.x = Math.max(-pad + halfW, Math.min(MAPW + pad - halfW, cam.x));
    cam.y = Math.max(-pad + halfH, Math.min(MAPH + pad - halfH, cam.y));
  }
  function screenToWorld(sx, sy) { return { x: cam.x + (sx - vw / 2) / cam.z, y: cam.y + (sy - vh / 2) / cam.z }; }
  Rd.worldToTile = function (wx, wy) { return [Math.floor(wx / TS), Math.floor(wy / TS)]; };
  Rd.focusTile = function (tx, ty) { cam.x = tx * TS; cam.y = ty * TS; clampCam(); };

  function dist(a, b) { return Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY); }

  function onDown(e) {
    cv.setPointerCapture(e.pointerId);
    pointers[e.pointerId] = e;
    dragMoved = 0;
    if (Object.keys(pointers).length === 2) {
      var pts = Object.values(pointers);
      pinchD0 = dist(pts[0], pts[1]); pinchZ0 = cam.z;
    }
    dragging = true;
  }
  function onMove(e) {
    if (!pointers[e.pointerId]) return;
    pointers[e.pointerId] = e;
    var pts = Object.values(pointers);
    if (pts.length === 2) {
      var d = dist(pts[0], pts[1]);
      if (pinchD0 > 10) { cam.z = Math.max(minZ, Math.min(maxZ, pinchZ0 * (d / pinchD0))); clampCam(); }
      return;
    }
    if (pts.length === 1 && dragging) {
      var r = cv.getBoundingClientRect(), dx = (e.movementX != null ? e.movementX : 0), dy = (e.movementY != null ? e.movementY : 0);
      if (!dx && !dy && e.__prev) { dx = e.clientX - e.__prev[0]; dy = e.clientY - e.__prev[1]; }
      cam.x -= dx / cam.z; cam.y -= dy / cam.z;
      dragMoved += Math.abs(dx) + Math.abs(dy);
      clampCam();
    }
  }
  function onUp(e) {
    var r = cv.getBoundingClientRect();
    var wasTap = dragMoved < 6 && Object.keys(pointers).length <= 1;
    delete pointers[e.pointerId];
    dragging = Object.keys(pointers).length > 0;
    if (wasTap && e.pointerType !== undefined) {
      var sx = e.clientX - r.left, sy = e.clientY - r.top, w = screenToWorld(sx, sy);
      if (placeMode) { onPlace && onPlace(w.x, w.y); }
      else handleTap(w.x, w.y);
    }
  }
  function onWheel(e) {
    e.preventDefault();
    var r = cv.getBoundingClientRect(), sx = e.clientX - r.left, sy = e.clientY - r.top;
    var before = screenToWorld(sx, sy);
    cam.z = Math.max(minZ, Math.min(maxZ, cam.z * Math.pow(1.0012, -e.deltaY)));
    var after = screenToWorld(sx, sy);
    cam.x += before.x - after.x; cam.y += before.y - after.y;
    clampCam();
  }

  function entAt(wx, wy) {
    var G = S.G, best = null, bd = 18;
    G.monsters.concat(G.humans).forEach(function (e) {
      if (!e.vis) return;
      var ex = e.px * TS, ey = e.py * TS, d = Math.hypot(wx - ex, wy - (ey - 8));
      if (d < bd) { bd = d; best = e; }
    });
    return best;
  }
  function bldAt(wx, wy) {
    var t = Rd.worldToTile(wx, wy), id = (t[1] >= 0 && t[1] < C.H && t[0] >= 0 && t[0] < C.W) ? W.occ[t[1] * C.W + t[0]] : 0;
    return id ? S.bld(id) : null;
  }
  function campAt(wx, wy) {
    var best = null, bd = 16;
    C.TERR.forEach(function (t) { var c = camps[t.id], d = Math.hypot(wx - c.x, wy - c.y); if (d < bd) { bd = d; best = t; } });
    return best;
  }
  function handleTap(wx, wy) {
    var e = entAt(wx, wy); if (e) { onTap && onTap({ type: "ent", id: e.id }); return; }
    var b = bldAt(wx, wy); if (b) { onTap && onTap({ type: "bld", id: b.id }); return; }
    var c = campAt(wx, wy); if (c) { onTap && onTap({ type: "camp", id: c.id }); return; }
    onTap && onTap(null);
  }

  /* ---------- drawing ---------- */
  function ensureTerrain() { if (W.version !== terrVer || !terrain) { terrain = Art.paintTerrain(W); terrVer = W.version; } }

  function drawCamp(t) {
    var c = camps[t.id], unlocked = MH.Raid.unlocked(t);
    var bx = c.x, by = c.y;
    ctx.save(); ctx.translate(bx, by);
    ctx.fillStyle = "rgba(0,0,0,.3)"; ctx.beginPath(); ctx.ellipse(0, 2, 9, 3, 0, 0, 7); ctx.fill();
    ctx.fillStyle = unlocked ? "#1a1410" : "#0c0a08";
    ctx.beginPath(); ctx.moveTo(-9, 0); ctx.lineTo(0, -16); ctx.lineTo(9, 0); ctx.closePath(); ctx.fill();
    ctx.fillStyle = unlocked ? "#b0402f" : "#4a4440";
    ctx.beginPath(); ctx.moveTo(-7, -1); ctx.lineTo(0, -13); ctx.lineTo(7, -1); ctx.closePath(); ctx.fill();
    ctx.fillStyle = "#1a1410"; ctx.fillRect(-1, -22, 2, 10);
    ctx.fillStyle = unlocked ? "#e0553f" : "#5a5450"; ctx.fillRect(0, -22, 6, 4);
    if (!unlocked) { ctx.fillStyle = "#f2b53c"; ctx.font = "8px monospace"; ctx.textAlign = "center"; ctx.fillText("✕", 0, -24); }
    ctx.restore();
    ctx.font = "bold 9px monospace"; ctx.textAlign = "center";
    ctx.fillStyle = "#000"; ctx.fillText(t.name, bx + 1, by - 25 + 1);
    ctx.fillStyle = unlocked ? "#f3ecd8" : "#8a8278"; ctx.fillText(t.name, bx, by - 25);
  }

  function drawEnt(e) {
    var x = e.px * TS, y = e.py * TS;
    var bob = (e.st === "working" || e.walk > 0.12) && !reduceMotion && Math.floor(performance.now() / 140) % 2 ? -1 : 0;
    ctx.fillStyle = "rgba(0,0,0,.3)"; ctx.beginPath(); ctx.ellipse(x, y + 1, 7, 2.4, 0, 0, 7); ctx.fill();
    var key = Art.entKey(e), spr = Art.sprite(key), scale = 1.15;
    var dw = spr.width * scale, dh = spr.height * scale;
    ctx.imageSmoothingEnabled = false;
    if (e.face) { ctx.save(); ctx.translate(x, 0); ctx.scale(-1, 1); ctx.drawImage(spr, -dw / 2, y - dh + bob, dw, dh); ctx.restore(); }
    else ctx.drawImage(spr, x - dw / 2, y - dh + bob, dw, dh);
    if (e.hpf != null && e.hpf < 0.99) {
      ctx.fillStyle = "#1a1410"; ctx.fillRect(x - 7, y - dh - 4, 14, 3);
      ctx.fillStyle = e.hpf > 0.5 ? "#7fcf5a" : e.hpf > 0.25 ? "#f2b53c" : "#e0553f"; ctx.fillRect(x - 6, y - dh - 3, 12 * Math.max(0, e.hpf), 1);
    }
    if (e.kind === "m" && e.rar >= 2) {
      ctx.fillStyle = C.RARITY[e.rar].color; ctx.beginPath(); ctx.arc(x, y - dh - 7, 2, 0, 7); ctx.fill();
    }
    if (selection && selection.type === "ent" && selection.id === e.id) {
      ctx.strokeStyle = "#f2b53c"; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.ellipse(x, y + 1, 8, 3, 0, 0, 7); ctx.stroke();
    }
  }

  function drawBuilding(b) {
    var def = C.BUILD[b.type], s = W.size(b.type, b.rot), art = Art.building(b.type, b.level, s[0], s[1]);
    var x = b.x * TS, y = (b.y + s[1]) * TS + 16;
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(art, x, y - art.height);
    if (selection && selection.type === "bld" && selection.id === b.id) {
      ctx.strokeStyle = "#f2b53c"; ctx.lineWidth = 2; ctx.strokeRect(b.x * TS + 1, b.y * TS + 1, s[0] * TS - 2, s[1] * TS - 2);
    }
    if (b.active && (b.type !== "trading")) {
      var bob = reduceMotion ? 0 : Math.sin(performance.now() / 260) * 1.5;
      ctx.fillStyle = "rgba(0,0,0,.35)"; ctx.beginPath(); ctx.arc(x + s[0] * TS / 2, y - art.height + 2 + bob, 6, 0, 7); ctx.fill();
      ctx.fillStyle = "#cde8c8"; ctx.beginPath(); ctx.arc(x + s[0] * TS / 2, y - art.height + 1 + bob, 5, 0, 7); ctx.fill();
    } else if (b.starved) {
      ctx.fillStyle = "#e0553f"; ctx.font = "10px monospace"; ctx.textAlign = "center"; ctx.fillText("!", x + s[0] * TS / 2, y - art.height - 2);
    } else if (b.full) {
      ctx.fillStyle = "#f2b53c"; ctx.font = "9px monospace"; ctx.textAlign = "center"; ctx.fillText("■", x + s[0] * TS / 2, y - art.height - 2);
    }
    if (def.cat !== "town" || b.type === "castle") {
      ctx.font = "8px monospace"; ctx.textAlign = "center";
      var lx = x + s[0] * TS / 2, ly = b.y * TS - 3;
      ctx.fillStyle = "#000"; ctx.fillText(def.name + " Lv" + b.level, lx + 1, ly + 1);
      ctx.fillStyle = "#f3ecd8"; ctx.fillText(def.name + " Lv" + b.level, lx, ly);
    }
  }

  function drawGhost(wx, wy) {
    if (!placeMode) return;
    var t = Rd.worldToTile(wx, wy), s = W.size(placeMode.type, placeMode.rot);
    var gx = t[0] - Math.floor(s[0] / 2), gy = t[1] - Math.floor(s[1] / 2);
    var pl = W.canPlace(placeMode.type, gx, gy, placeMode.rot, placeMode.movingId || 0);
    placeMode.at = [gx, gy];
    ctx.save(); ctx.globalAlpha = 0.55;
    var art = Art.building(placeMode.type, 1, s[0], s[1]);
    ctx.drawImage(art, gx * TS, (gy + s[1]) * TS + 16 - art.height);
    ctx.restore();
    ctx.strokeStyle = pl.ok ? "#7fcf5a" : "#e0553f"; ctx.lineWidth = 2;
    ctx.strokeRect(gx * TS + 1, gy * TS + 1, s[0] * TS - 2, s[1] * TS - 2);
    ctx.fillStyle = pl.ok ? "rgba(127,207,90,.18)" : "rgba(224,85,63,.18)";
    ctx.fillRect(gx * TS, gy * TS, s[0] * TS, s[1] * TS);
    placeMode.valid = pl.ok; placeMode.reason = pl.reason;
  }

  Rd.frame = function () {
    ensureTerrain();
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = "#06040e"; ctx.fillRect(0, 0, vw, vh);
    ctx.save();
    ctx.translate(vw / 2, vh / 2); ctx.scale(cam.z, cam.z); ctx.translate(-cam.x, -cam.y);
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(terrain, 0, 0);
    C.TERR.forEach(drawCamp);
    var items = [];
    S.G.buildings.forEach(function (b) { var s = W.size(b.type, b.rot); items.push({ y: (b.y + s[1]) * TS, draw: function () { drawBuilding(b); } }); });
    S.G.monsters.forEach(function (m) { if (m.vis) items.push({ y: m.py * TS, draw: function () { drawEnt(m); } }); });
    S.G.humans.forEach(function (h) { if (h.vis) items.push({ y: h.py * TS, draw: function () { drawEnt(h); } }); });
    items.sort(function (a, b) { return a.y - b.y; });
    items.forEach(function (it) { it.draw(); });
    if (placeMode) { var mp = pointers[Object.keys(pointers)[0]]; var wp = mp ? screenToWorld(mp.clientX - cv.getBoundingClientRect().left, mp.clientY - cv.getBoundingClientRect().top) : { x: cam.x, y: cam.y }; drawGhost(wp.x, wp.y); }
    ctx.restore();
  };

  Rd.centerOnCastle = function () {
    var cb = S.bld(S.G.castleId); if (cb) Rd.focusTile(cb.x + 2.5, cb.y + 3);
  };
})();
