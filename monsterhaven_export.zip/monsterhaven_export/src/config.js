/* MONSTERHAVEN config: every balance number lives here. Rates are per minute unless noted. */
(function () {
  "use strict";
  var MH = window.MH = window.MH || {};
  var C = MH.C = {};

  C.TILE = 16; C.W = 64; C.H = 48;
  C.SAVE_KEY = "monsterhaven-save-v1";
  C.AUTOSAVE = 15;                 // seconds
  C.OFFLINE_CAP = 8 * 3600;        // max seconds credited while away
  C.OFFLINE_UPTIME = 0.7;          // share of time workers are actually working
  C.DAY_LEN = 480;                 // seconds per day/night cycle
  C.START = { gold: 220, food: 140, wood: 120, stone: 70, iron: 12, essence: 0 };
  C.RES = ["gold", "food", "wood", "stone", "iron", "essence"];
  C.RES_NAME = { gold: "Gold", food: "Food", wood: "Wood", stone: "Stone", iron: "Iron", essence: "Essence" };
  C.RES_COLOR = { gold: "#f2c14e", food: "#e0553f", wood: "#d9a766", stone: "#aab2bf", iron: "#9db4d0", essence: "#c58cf0" };
  C.BASE_CAP = 300;                // per resource, before storages
  C.PRICE = { food: 0.8, wood: 1, stone: 1.4, iron: 4, essence: 12 }; // gold value for trading
  C.TRADE_LOT = 10;
  C.HUMAN_EAT = 0.6;
  C.SPEEDS = [1, 2, 4, 8];

  C.RARITY = [
    { id: "common", name: "Common", mult: 1, color: "#b8b2a0", w: 70 },
    { id: "uncommon", name: "Uncommon", mult: 1.15, color: "#7fcf5a", w: 20 },
    { id: "rare", name: "Rare", mult: 1.35, color: "#5aa0d0", w: 7 },
    { id: "epic", name: "Epic", mult: 1.65, color: "#b06ad9", w: 2.5 },
    { id: "legendary", name: "Legendary", mult: 2.1, color: "#f2b53c", w: 0.5 }
  ];

  C.TRAITS = {
    lazy: { name: "Lazy", desc: "Works 20% slower.", good: false },
    hardworking: { name: "Hardworking", desc: "Works 20% faster.", good: true },
    greedy: { name: "Greedy", desc: "Costs 25% more to recruit, 0.3 gold/min upkeep.", good: false },
    loyal: { name: "Loyal", desc: "Never deserts, small happiness boost.", good: true },
    brave: { name: "Brave", desc: "+10% attack on raids.", good: true },
    intelligent: { name: "Intelligent", desc: "+30% research speed, +20% XP.", good: true },
    aggressive: { name: "Aggressive", desc: "+15% damage on raids.", good: true }
  };

  /* monster species. jobs: efficiency per building type (missing = 0.5) */
  C.SPECIES = {
    goblin: { name: "Goblin", role: "Worker", hp: 30, atk: 6, def: 2, work: 1.0, eat: 0.5, speed: 1.05, unlock: 1, cost: { gold: 40 },
      jobs: { farm: 0.8, lumber: 0.8, workshop: 0.95, mine: 0.7, alchemist: 0.6, trading: 0.95, blacksmith: 0.8, temple: 0.7, tower: 0.6 },
      cskill: "Sneak Attack", cdesc: "20% chance to strike for 1.8x damage.", wskill: "Nimble Fingers", wdesc: "+12% work speed (Lv5)." },
    kobold: { name: "Kobold", role: "Miner", hp: 26, atk: 5, def: 3, work: 1.0, eat: 0.4, speed: 1.0, unlock: 1, cost: { gold: 55 },
      jobs: { mine: 1.35, farm: 0.6, lumber: 0.7, workshop: 0.8, blacksmith: 0.9, alchemist: 0.6, trading: 0.7, temple: 0.6, tower: 0.6 },
      cskill: "Burrow Strike", cdesc: "+30% damage in the first two rounds.", wskill: "Deep Delver", wdesc: "+12% work speed (Lv5)." },
    slime: { name: "Slime", role: "Alchemist", hp: 40, atk: 4, def: 1, work: 1.0, eat: 0.4, speed: 0.8, unlock: 2, cost: { gold: 80 },
      jobs: { alchemist: 1.35, workshop: 1.1, farm: 0.8, temple: 0.9, tower: 0.8, trading: 0.7, blacksmith: 0.5, mine: 0.4, lumber: 0.4 },
      cskill: "Ooze Mend", cdesc: "Heals the weakest ally for 8% max HP each round.", wskill: "Catalyst", wdesc: "+12% work speed (Lv5)." },
    orc: { name: "Orc", role: "Soldier", hp: 60, atk: 11, def: 5, work: 1.0, eat: 0.8, speed: 1.0, unlock: 2, cost: { gold: 110 },
      jobs: { lumber: 1.25, mine: 1.1, blacksmith: 1.2, farm: 0.6, workshop: 0.7, temple: 0.5, tower: 0.4, alchemist: 0.4, trading: 0.5 },
      cskill: "Cleave", cdesc: "Hits a second foe for half damage.", wskill: "Heavy Hauler", wdesc: "+12% work speed (Lv5)." },
    skeleton: { name: "Skeleton", role: "Mage-hand", hp: 38, atk: 9, def: 3, work: 1.0, eat: 0.2, speed: 1.0, unlock: 3, cost: { gold: 150, essence: 5 },
      jobs: { tower: 1.4, temple: 1.2, alchemist: 1.0, blacksmith: 0.8, workshop: 0.7, trading: 0.5, mine: 0.6, lumber: 0.5, farm: 0.3 },
      cskill: "Bone Ward", cdesc: "+25% defense in battle.", wskill: "Arcane Study", wdesc: "+12% work speed (Lv5)." },
    vampire: { name: "Vampire", role: "Elite", hp: 85, atk: 16, def: 7, work: 1.0, eat: 0.6, speed: 1.15, unlock: 4, cost: { gold: 420, essence: 40 },
      jobs: { temple: 1.4, tower: 1.1, trading: 1.2, alchemist: 0.9, blacksmith: 0.8, workshop: 0.6, mine: 0.5, lumber: 0.5, farm: 0.3 },
      cskill: "Blood Drain", cdesc: "Heals for 25% of damage dealt. Leads the squad: +10% ATK.", wskill: "Dark Charisma", wdesc: "+12% work speed (Lv5)." }
  };
  C.EVOLVE = { goblin: "Hobgoblin", kobold: "Dragonkin", slime: "Ooze King", orc: "Warlord", skeleton: "Lich", vampire: "Elder Vampire" };
  C.EVOLVE_COST = { gold: 300, essence: 25 };
  C.EVOLVE_LEVEL = 10;
  C.EVOLVE_MULT = 1.5;
  C.MAX_LEVEL = 20;
  C.RECRUIT_GREEDY = 1.25;

  C.MNAMES = {
    goblin: ["Grix", "Snaggle", "Mog", "Nib", "Skrit", "Zook", "Pik", "Rizzle", "Wort", "Gnash"],
    kobold: ["Dink", "Tuk", "Zerp", "Bolt", "Kiv", "Rusk", "Yip", "Scree", "Nok", "Dree"],
    slime: ["Plop", "Glorp", "Squee", "Blub", "Splodge", "Dribble", "Gloop", "Sludge", "Wobb", "Drip"],
    orc: ["Brogga", "Thud", "Gorm", "Mulch", "Hagrim", "Bruk", "Ugda", "Karg", "Zug", "Dolm"],
    skeleton: ["Rattles", "Bonk", "Clatter", "Femur", "Tibia", "Marrow", "Sternum", "Rib", "Cranky", "Dusty"],
    vampire: ["Vesper", "Morwen", "Lucian", "Sable", "Dracul", "Nyx", "Corvin", "Mirela", "Aldric", "Selene"]
  };
  C.HFIRST = ["Alden", "Brin", "Cora", "Dorn", "Edda", "Finn", "Gale", "Hale", "Ivo", "Jora", "Kell", "Lena", "Marn", "Nell", "Orin", "Pia", "Quill", "Rolf", "Sera", "Tam", "Una", "Vik", "Wren", "Yara"];
  C.HLAST = ["Miller", "Cooper", "Fletcher", "Thatcher", "Smith", "Brook", "Hill", "Marsh", "Ward", "Fisher"];

  /* human occupations. skill = which building type they are best at */
  C.HUMAN = {
    farmer: { name: "Farmer", site: "farm", prod: [0.9, 1.1], hp: 40 },
    miner: { name: "Miner", site: "mine", prod: [0.9, 1.1], hp: 48 },
    lumberjack: { name: "Lumberjack", site: "lumber", prod: [0.9, 1.1], hp: 52 },
    craftsman: { name: "Craftsman", site: "workshop", prod: [0.9, 1.15], hp: 38 },
    researcher: { name: "Researcher", site: "tower", prod: [0.9, 1.2], hp: 32 },
    adventurer: { name: "Adventurer", site: null, prod: [1.0, 1.4], hp: 80, escape: 3 }
  };
  C.HUMAN_MISMATCH = 0.6;
  C.ESCAPE_BASE = 0.035;           // chance per human per 30s check, before security
  C.ESCAPE_CHECK = 30;

  /* buildings. cat: town | human | monster | advanced. kind: who can work there */
  C.BUILD = {
    castle: { name: "Dark Castle", cat: "town", size: [5, 4], cost: {}, unlock: 1, max: 1, maxLevel: 5, fixed: true,
      desc: "Your headquarters. Upgrade it to unlock new buildings, species and lands. Houses 4 monsters (+2 per level)." },
    house: { name: "Monster House", cat: "town", size: [2, 2], cost: { wood: 30, stone: 15 }, unlock: 1, max: 14, maxLevel: 3, grow: 0.12,
      desc: "Housing for monsters. 4 beds, +2 per level." },
    storage: { name: "Storage", cat: "town", size: [3, 2], cost: { wood: 40, stone: 20 }, unlock: 1, max: 6, maxLevel: 4, grow: 0.2,
      desc: "Raises the storage limit of every resource by 300 (+150 per level)." },
    trading: { name: "Trading Post", cat: "town", size: [3, 2], cost: { wood: 50, stone: 30, gold: 40 }, unlock: 1, max: 1, maxLevel: 3, slots: 2, kind: "monster", out: { gold: 3 },
      desc: "Buy and sell resources. Monster traders earn gold on the side. Upgrades improve prices." },
    farm: { name: "Human Farm", cat: "human", size: [4, 3], cost: { wood: 45, stone: 20 }, unlock: 1, max: 6, maxLevel: 4, grow: 0.15, slots: 4, kind: "any", human: "farmer", out: { food: 9 },
      desc: "Workers grow food. Farmers work best here." },
    mine: { name: "Human Mine", cat: "human", size: [3, 3], cost: { wood: 50, stone: 25 }, unlock: 1, max: 5, maxLevel: 4, grow: 0.15, slots: 4, kind: "any", human: "miner", out: { stone: 5, iron: 1.8 },
      desc: "Workers dig stone and iron. Kobolds and miners excel." },
    lumber: { name: "Lumber Camp", cat: "human", size: [3, 3], cost: { wood: 30, stone: 10 }, unlock: 1, max: 5, maxLevel: 4, grow: 0.15, slots: 4, kind: "any", human: "lumberjack", out: { wood: 8 },
      desc: "Workers chop wood. Lumberjacks and orcs work best." },
    prison: { name: "Human Prison", cat: "human", size: [3, 3], cost: { wood: 60, stone: 60 }, unlock: 1, max: 4, maxLevel: 4, grow: 0.2,
      desc: "Holds 6 captives (+3 per level). Higher levels make escapes less likely." },
    workshop: { name: "Human Workshop", cat: "human", size: [3, 2], cost: { wood: 70, stone: 50, gold: 60 }, unlock: 2, max: 3, maxLevel: 4, grow: 0.2, slots: 3, kind: "any", human: "craftsman", out: { gold: 6 }, inp: { wood: 1, stone: 0.6 },
      desc: "Turns wood and stone into trade goods worth gold. Craftsmen work best." },
    den: { name: "Breeding Den", cat: "monster", size: [3, 3], cost: { wood: 80, stone: 60, gold: 120, food: 40 }, unlock: 3, max: 2, maxLevel: 3, grow: 0.3,
      desc: "Produces a new monster every few minutes if there is housing and food." },
    tavern: { name: "Tavern", cat: "monster", size: [3, 3], cost: { wood: 70, stone: 40, gold: 80 }, unlock: 2, max: 3, maxLevel: 3, grow: 0.2, upkeep: 0.5,
      desc: "Raises happiness and with it everyone's productivity." },
    training: { name: "Training Ground", cat: "monster", size: [4, 3], cost: { wood: 60, stone: 60, gold: 100 }, unlock: 2, max: 2, maxLevel: 3, grow: 0.25, slots: 4, kind: "monster", upkeep: 0.5,
      desc: "Assigned monsters train and gain XP steadily." },
    barracks: { name: "Barracks", cat: "monster", size: [4, 3], cost: { wood: 80, stone: 80, gold: 120, iron: 10 }, unlock: 2, max: 2, maxLevel: 3, grow: 0.25, upkeep: 0.5,
      desc: "Lets squads field more monsters on raids (+1 per level)." },
    blacksmith: { name: "Blacksmith", cat: "monster", size: [3, 2], cost: { wood: 60, stone: 60, gold: 100, iron: 20 }, unlock: 3, max: 2, maxLevel: 5, grow: 0.25, slots: 2, kind: "monster",
      desc: "Craft weapons and armor. Needs at least one monster working here. Level sets the best tier." },
    alchemist: { name: "Alchemist", cat: "monster", size: [3, 2], cost: { wood: 50, stone: 40, gold: 140 }, unlock: 2, max: 2, maxLevel: 4, grow: 0.25, slots: 2, kind: "monster", out: { essence: 1.1 }, inp: { stone: 0.8, wood: 0.4 },
      desc: "Brews magic essence from stone and wood. Slimes are masters of it." },
    tower: { name: "Research Tower", cat: "advanced", size: [3, 3], cost: { wood: 90, stone: 100, gold: 200 }, unlock: 2, max: 1, maxLevel: 4, grow: 0.3, slots: 2, kind: "any", human: "researcher",
      desc: "Required for research. Researchers and skeletons speed it up." },
    watchtower: { name: "Watchtower", cat: "advanced", size: [2, 2], cost: { wood: 50, stone: 60, iron: 6 }, unlock: 2, max: 6, maxLevel: 3, grow: 0.2, upkeep: 0.3,
      desc: "Village defense. Each tower makes prisoner escapes less likely." },
    temple: { name: "Dark Temple", cat: "advanced", size: [3, 3], cost: { wood: 100, stone: 140, gold: 260, essence: 30 }, unlock: 4, max: 1, maxLevel: 3, grow: 0.3, slots: 2, kind: "monster", out: { essence: 0.9 },
      desc: "Monster worshippers produce essence. Grants +5% monster work speed per level." },
    gate: { name: "Dungeon Gate", cat: "advanced", size: [3, 2], cost: { wood: 120, stone: 160, gold: 300, iron: 40, essence: 40 }, unlock: 3, max: 1, maxLevel: 1,
      desc: "Opens the road to the far territories (Walled Town and beyond)." },
    portal: { name: "Portal", cat: "advanced", size: [3, 3], cost: { wood: 200, stone: 260, gold: 1500, iron: 120, essence: 200 }, unlock: 5, max: 1, maxLevel: 1,
      desc: "Opens a rift to another world: the Hero's Citadel." }
  };
  C.BUILD_CATS = [["town", "Town"], ["human", "Human"], ["monster", "Monster"], ["advanced", "Advanced"]];
  C.COUNT_GROW = 0.12;             // cost growth per building of the same type already owned
  C.UP_BASE = 1.7;                 // upgrade cost multiplier base: cost * UP_BASE^level
  C.LEVEL_OUTPUT = 0.35;           // +35% output per building level above 1
  C.REFUND = 0.5;
  C.CASTLE_UP = [null,
    { cost: { wood: 140, stone: 110, gold: 200 }, pop: 6, need: ["farm"], unlocks: "Workshop, Tavern, Barracks, Training Ground, Alchemist, Tower, Watchtower; Slimes and Orcs; the Mining Camp and Outpost" },
    { cost: { wood: 320, stone: 280, gold: 450, iron: 40 }, pop: 12, need: ["tavern", "barracks"], unlocks: "Breeding Den, Dungeon Gate, Blacksmith; Skeletons; the Walled Town and Keep" },
    { cost: { wood: 700, stone: 620, gold: 1100, iron: 140, essence: 30 }, pop: 20, need: ["tower", "blacksmith"], unlocks: "Dark Temple; Vampires; the Mage Academy" },
    { cost: { wood: 1500, stone: 1300, gold: 2600, iron: 360, essence: 120 }, pop: 32, need: ["temple", "gate"], unlocks: "Portal and the Hero's Citadel" }
  ];
  C.CASTLE_MAX = C.CASTLE_UP.length; // levels 1..5; CASTLE_UP[1..4] are the upgrades from level 1..4

  C.CRAFT_COST = function (tier) { var c = { iron: 6 * tier, gold: 20 * tier }; if (tier >= 4) c.essence = 5 * (tier - 3); return c; };
  C.WEAPONS = [["Rusty Blade", 3], ["Iron Cleaver", 7], ["Steel Fang", 12], ["Darksteel Reaver", 19], ["Voidforged Edge", 28]];
  C.ARMORS = [["Scrap Hide", 2], ["Iron Plate", 5], ["Steel Mail", 9], ["Darksteel Plate", 14], ["Voidforged Aegis", 21]];

  C.SQUAD_BASE = 3;
  C.DEN_INTERVAL = 180;
  C.DEN_POOL = [["goblin", 50], ["kobold", 25], ["slime", 15], ["orc", 10]];
  C.QUEST_ROWS = 3;

  /* territories: str = total enemy power (goblin = ~34 power). pos = fixed map tile of the camp marker, always outside the walls at every castle level. */
  C.TERR = [
    { id: "farmstead", name: "Human Farmstead", tier: 1, castle: 1, str: 80, travel: 50, pos: [31, 46], rew: { gold: [35, 70], food: [50, 90], wood: [15, 35] }, cap: { max: 2, types: ["farmer", "farmer", "lumberjack"], rar: 0 }, equip: 0.05, desc: "Scattered farmers and a few pitchforks." },
    { id: "village", name: "Roadside Village", tier: 2, castle: 1, str: 170, travel: 80, pos: [9, 46], rew: { gold: [70, 130], food: [60, 110], wood: [30, 60], stone: [10, 30] }, cap: { max: 3, types: ["farmer", "lumberjack", "craftsman"], rar: 0 }, equip: 0.1, desc: "A village with a militia and a bell tower." },
    { id: "mining", name: "Human Mining Camp", tier: 3, castle: 2, str: 300, travel: 110, pos: [55, 45], rew: { gold: [90, 170], stone: [50, 110], iron: [15, 35] }, cap: { max: 3, types: ["miner", "miner", "craftsman"], rar: 0 }, equip: 0.12, desc: "Stocked ore carts and tired guards." },
    { id: "outpost", name: "Military Outpost", tier: 4, castle: 2, str: 520, travel: 150, pos: [2, 24], rew: { gold: [160, 280], iron: [30, 60], food: [40, 80] }, cap: { max: 3, types: ["miner", "craftsman", "adventurer"], rar: 1 }, equip: 0.25, desc: "Soldiers behind a palisade. Good loot." },
    { id: "town", name: "Walled Town", tier: 5, castle: 3, gate: "gate", str: 880, travel: 210, pos: [61, 20], rew: { gold: [300, 520], wood: [80, 140], stone: [60, 120], iron: [40, 80], essence: [3, 8] }, cap: { max: 4, types: ["craftsman", "researcher", "farmer", "adventurer"], rar: 1 }, equip: 0.3, desc: "Thick walls, deep coffers." },
    { id: "keep", name: "Knights' Keep", tier: 6, castle: 3, gate: "gate", str: 1400, travel: 270, pos: [2, 2], rew: { gold: [500, 900], iron: [80, 150], essence: [6, 14] }, cap: { max: 4, types: ["adventurer", "craftsman"], rar: 2 }, equip: 0.4, desc: "Armored knights and their war-hounds." },
    { id: "academy", name: "Mage Academy", tier: 7, castle: 4, gate: "gate", str: 2200, travel: 340, pos: [61, 2], rew: { gold: [700, 1200], essence: [25, 50] }, cap: { max: 4, types: ["researcher", "researcher", "adventurer"], rar: 2 }, equip: 0.35, desc: "Spellbooks, wards and apprentices." },
    { id: "citadel", name: "Hero's Citadel", tier: 8, castle: 5, gate: "portal", str: 3600, travel: 420, pos: [31, 1], rew: { gold: [1500, 2500], iron: [150, 260], essence: [60, 110] }, cap: { max: 5, types: ["adventurer"], rar: 3 }, equip: 0.6, desc: "The final stronghold of the heroes." }
  ];

  /* research. fx keys are summed into the modifier table in sim.js */
  C.RESEARCH = [
    { id: "farming1", branch: "Economy", name: "Better Farming", cost: { gold: 80, wood: 40 }, time: 45, req: [], castle: 1, fx: { food: 0.25 }, desc: "+25% food production." },
    { id: "farming2", branch: "Economy", name: "Crop Rotation", cost: { gold: 220, wood: 100, essence: 8 }, time: 120, req: ["farming1"], castle: 2, fx: { food: 0.3 }, desc: "+30% more food production." },
    { id: "mining1", branch: "Economy", name: "Improved Mining", cost: { gold: 100, stone: 60 }, time: 60, req: [], castle: 1, fx: { mine: 0.25 }, desc: "+25% stone and iron output." },
    { id: "production1", branch: "Economy", name: "Faster Production", cost: { gold: 260, essence: 10 }, time: 150, req: ["mining1"], castle: 2, fx: { prod: 0.15 }, desc: "+15% output from every production building." },
    { id: "storage1", branch: "Economy", name: "Larger Storage", cost: { gold: 120, wood: 100 }, time: 70, req: [], castle: 1, fx: { cap: 0.5 }, desc: "+50% storage limits." },
    { id: "storage2", branch: "Economy", name: "Deep Vaults", cost: { gold: 400, stone: 300, essence: 12 }, time: 160, req: ["storage1"], castle: 3, fx: { cap: 0.75 }, desc: "+75% more storage limits." },
    { id: "weapons1", branch: "Military", name: "Improved Weapons", cost: { gold: 120, iron: 20, essence: 4 }, time: 90, req: [], castle: 2, fx: { atk: 0.1, tier: 1 }, desc: "+10% attack and unlocks tier 3 weapons." },
    { id: "armor1", branch: "Military", name: "Better Armor", cost: { gold: 120, iron: 20, essence: 4 }, time: 90, req: [], castle: 2, fx: { def: 0.1, tier: 1 }, desc: "+10% defense and unlocks tier 3 armor." },
    { id: "squad1", branch: "Military", name: "Stronger Squads", cost: { gold: 250, iron: 30, essence: 10 }, time: 140, req: ["weapons1"], castle: 3, fx: { squad: 1 }, desc: "+1 monster per squad." },
    { id: "defense1", branch: "Military", name: "Defensive Works", cost: { stone: 200, iron: 30, essence: 6 }, time: 120, req: ["armor1"], castle: 3, fx: { sec: 0.5 }, desc: "+50% security from watchtowers and prison." },
    { id: "breeding1", branch: "Monsters", name: "Faster Breeding", cost: { gold: 150, food: 80, essence: 5 }, time: 80, req: [], castle: 3, fx: { den: 0.4 }, desc: "Dens work 40% faster." },
    { id: "evolution", branch: "Monsters", name: "Monster Evolution", cost: { gold: 300, essence: 30 }, time: 180, req: ["breeding1"], castle: 3, fx: { evolve: 1 }, desc: "Level 10 monsters can evolve into stronger forms." },
    { id: "traits1", branch: "Monsters", name: "Improved Traits", cost: { gold: 200, essence: 12 }, time: 120, req: ["breeding1"], castle: 3, fx: { luck: 1 }, desc: "Recruits and offspring roll better rarity and traits." },
    { id: "housing1", branch: "Monsters", name: "Deeper Burrows", cost: { wood: 200, stone: 150 }, time: 100, req: [], castle: 2, fx: { housing: 0.25 }, desc: "+25% housing." },
    { id: "humanprod1", branch: "Humans", name: "Overseers", cost: { gold: 120, wood: 60 }, time: 60, req: [], castle: 1, fx: { hprod: 0.2 }, desc: "+20% human productivity." },
    { id: "facilities1", branch: "Humans", name: "Larger Facilities", cost: { gold: 240, stone: 160, essence: 10 }, time: 130, req: ["humanprod1"], castle: 3, fx: { hslots: 1 }, desc: "+1 worker slot in every human facility." },
    { id: "security1", branch: "Humans", name: "Chains and Wards", cost: { gold: 180, iron: 25, essence: 8 }, time: 90, req: [], castle: 2, fx: { escape: 0.4 }, desc: "-40% prisoner escape chance." }
  ];

  C.QUESTS = [
    { id: "q_goblins", key: "goblins", goal: 5, title: "Recruit five goblins", desc: "Hire goblins in the Monsters menu (you start with three).", reward: { gold: 120 } },
    { id: "q_farm", key: "farm", goal: 1, title: "Build a Human Farm", desc: "Open Build > Human and place a farm.", reward: { wood: 60, stone: 40 } },
    { id: "q_work", key: "workers", goal: 4, title: "Put four workers on the job", desc: "Select a building and assign workers.", reward: { gold: 80 } },
    { id: "q_raid", key: "raids", goal: 1, title: "Complete a raid", desc: "Military > pick the Human Farmstead and send a squad.", reward: { gold: 150, iron: 10 } },
    { id: "q_capture", key: "captured", goal: 3, title: "Capture three humans", desc: "Raids can capture people. Keep room in the prison.", reward: { food: 120, gold: 100 } },
    { id: "q_human", key: "hworkers", goal: 1, title: "Put a human to work", desc: "Assign a captive to a farm, mine or lumber camp.", reward: { wood: 80 } },
    { id: "q_research", key: "farming1", goal: 1, title: "Research Better Farming", desc: "Build a Research Tower (castle level 2), then research.", reward: { essence: 6, gold: 100 } },
    { id: "q_castle2", key: "castle2", goal: 1, title: "Upgrade the Dark Castle to level 2", desc: "Select the castle and upgrade it.", reward: { gold: 200, stone: 60 } },
    { id: "q_tavern", key: "tavern", goal: 1, title: "Build a Tavern", desc: "Happy monsters work harder.", reward: { gold: 100 } },
    { id: "q_ten", key: "monsters", goal: 10, title: "Grow to ten monsters", desc: "Build houses, then recruit.", reward: { gold: 250, iron: 20 } },
    { id: "q_craft", key: "crafted", goal: 1, title: "Craft your first equipment", desc: "Build a Blacksmith (castle level 3), staff it, craft an item.", reward: { iron: 25 } },
    { id: "q_lvl3", key: "lvl3", goal: 1, title: "Upgrade any building to level 3", desc: "Higher levels produce more and look grander.", reward: { gold: 300, stone: 100 } },
    { id: "q_win5", key: "wins", goal: 5, title: "Win five raids", desc: "Stronger squads and better gear help.", reward: { gold: 400, iron: 60 } },
    { id: "q_adv", key: "adventurers", goal: 1, title: "Capture an adventurer", desc: "Outposts and beyond hold adventurers.", reward: { gold: 300, essence: 12 } },
    { id: "q_castle3", key: "castle3", goal: 1, title: "Upgrade the Dark Castle to level 3", desc: "Unlocks the Den, Gate and Blacksmith.", reward: { gold: 500, iron: 50 } },
    { id: "q_evolve", key: "evolved", goal: 1, title: "Evolve a monster", desc: "Research Monster Evolution, then evolve a level 10 monster.", reward: { essence: 30, gold: 600 } }
  ];

  C.TUTORIAL = [
    ["Welcome to Monsterhaven", "You rule a monster village. Monsters live and work here. Humans are captured in raids and put to work. Grow your settlement into a dark kingdom."],
    ["Moving around", "Drag the map to pan. Scroll or pinch to zoom. Tap a building, monster or human to see its panel and actions."],
    ["Build and assign", "Open Build to place buildings. Then select a building and assign workers. Production only happens while workers are present at the site."],
    ["Recruit and raid", "Hire monsters in the Monsters menu. In Military, send a squad on a raid to earn loot and capture humans."],
    ["Always an objective", "The Quests panel on the left shows your next goals. Claim rewards when they are ready. The game saves automatically and keeps working while you are away."]
  ];
})();
