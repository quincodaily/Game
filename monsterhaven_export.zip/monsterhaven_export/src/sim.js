/* MONSTERHAVEN simulation: state, economy, research, quests, saving, offline progress. */
(function () {
  "use strict";
  var MH = window.MH, C = MH.C, W = MH.World, Art = MH.Art;
  var S = MH.Sim = { G: null, D: { mods: {}, cnt: {} }, pops: [], gross: {} };
  var G = null, D = S.D;
  var BUILD = C.BUILD, SPECIES = C.SPECIES;

  function R() { return Math.random(); }
  function rint(a, b) { return a + Math.floor(R() * (b - a + 1)); }
  function pick(a) { return a[Math.floor(R() * a.length)]; }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function wpick(list) { var t = 0, i; for (i = 0; i < list.length; i++) t += list[i][1]; var r = R() * t; for (i = 0; i < list.length; i++) { r -= list[i][1]; if (r <= 0) return list[i][0]; } return list[0][0]; }
  S.rint = rint; S.pick = pick; S.clamp = clamp;

  S.ent = function (id) {
    var i; for (i = 0; i < G.monsters.length; i++) if (G.monsters[i].id === id) return G.monsters[i];
    for (i = 0; i < G.humans.length; i++) if (G.humans[i].id === id) return G.humans[i];
    return null;
  };
  S.bld = function (id) { for (var i = 0; i < G.buildings.length; i++) if (G.buildings[i].id === id) return G.buildings[i]; return null; };

  S.addLog = function (msg, type) {
    G.logSeq = (G.logSeq || 0) + 1;
    G.log.unshift({ t: Math.round(G.time), msg: msg, type: type || "info", seq: G.logSeq });
    if (G.log.length > 80) G.log.length = 80;
  };

  /* ---------- rolls ---------- */
  function rollRarity(boost) {
    var luck = D.mods.luck ? 1.8 : 1, list = C.RARITY.map(function (r, i) { return [i, i === 0 ? r.w : r.w * luck * (boost ? 1 + boost * i : 1)]; });
    return wpick(list);
  }
  function rollTrait() {
    var keys = Object.keys(C.TRAITS), luck = D.mods.luck;
    return wpick(keys.map(function (k) { return [k, C.TRAITS[k].good ? (luck ? 1.6 : 1) : (luck ? 0.5 : 1)]; }));
  }
  function mname(sp) { var used = {}; G.monsters.forEach(function (m) { used[m.name] = 1; }); var free = C.MNAMES[sp].filter(function (n) { return !used[n]; }); return free.length ? pick(free) : pick(C.MNAMES[sp]) + " " + rint(2, 9); }

  S.newMonster = function (sp, opts) {
    opts = opts || {};
    var m = { id: G.nid++, kind: "m", name: mname(sp), sp: sp, level: 1, xp: 0, rar: opts.rar != null ? opts.rar : rollRarity(), trait: opts.trait || rollTrait(),
      job: null, eq: { weapon: null, armor: null }, hpf: 1, energy: 100, st: "idle", evolved: false, away: false };
    var dt = opts.at || W.doorTile(S.bld(G.castleId));
    m.px = dt[0] + 0.5; m.py = dt[1] + 0.5;
    G.monsters.push(m);
    return m;
  };
  S.newHuman = function (occ, boost, at) {
    var def = C.HUMAN[occ], rar = rollRarity(boost || 0), rm = C.RARITY[rar].mult;
    var pr = def.prod, prod = (pr[0] + R() * (pr[1] - pr[0])) * Math.pow(rm, 0.7);
    var skills = { farm: rint(1, 6), mine: rint(1, 6), lumber: rint(1, 6), workshop: rint(1, 6), tower: rint(1, 6) };
    if (def.site) skills[def.site] = rint(6, 10);
    var h = { id: G.nid++, kind: "h", name: pick(C.HFIRST) + " " + pick(C.HLAST), occ: occ, rar: rar, hp: Math.round(def.hp * rm), stamina: 100,
      prod: Math.round(prod * 100) / 100, skills: skills, escape: (def.escape || 1) * (0.7 + R() * 0.6), job: null, st: "idle", energy: 100 };
    var d = at || W.gateTile();
    h.px = d[0] + 0.5; h.py = d[1] + 0.5;
    G.humans.push(h);
    return h;
  };

  /* ---------- stats ---------- */
  S.xpNeed = function (lv) { return 20 + Math.round(14 * Math.pow(lv, 1.45)); };
  S.stat = function (m, k) {
    var sp = SPECIES[m.sp], v = sp[k] * (1 + 0.09 * (m.level - 1)) * C.RARITY[m.rar].mult * (m.evolved ? C.EVOLVE_MULT : 1);
    if (k === "atk" && m.eq.weapon) v += m.eq.weapon.val;
    if (k === "def" && m.eq.armor) v += m.eq.armor.val;
    if (k === "atk") v *= 1 + D.mods.atk;
    if (k === "def") v *= 1 + D.mods.def;
    return v;
  };
  S.power = function (m) { return S.stat(m, "hp") * m.hpf * 0.4 + S.stat(m, "atk") * 3 + S.stat(m, "def") * 2; };
  S.skills = function (m) {
    var sp = SPECIES[m.sp], out = [];
    if (m.level >= 3) out.push({ name: sp.cskill, desc: sp.cdesc });
    if (m.level >= 5) out.push({ name: sp.wskill, desc: sp.wdesc });
    return out;
  };
  S.addXp = function (m, amt) {
    if (m.level >= C.MAX_LEVEL) return;
    m.xp += amt * (m.trait === "intelligent" ? 1.2 : 1);
    var need = S.xpNeed(m.level);
    while (m.xp >= need && m.level < C.MAX_LEVEL) {
      m.xp -= need; m.level++; need = S.xpNeed(m.level);
      if (m.level === 3 || m.level === 5 || m.level === C.EVOLVE_LEVEL || m.level % 5 === 0) S.addLog(m.name + " reached level " + m.level + ".", "good");
    }
  };
  function mult(res) {
    var m = 1 + D.mods.prod;
    if (res === "food") m *= 1 + D.mods.food;
    if (res === "stone" || res === "iron") m *= 1 + D.mods.mine;
    return m;
  }
  S.workEffM = function (m, b) {
    var sp = SPECIES[m.sp], e = sp.work * (sp.jobs[b.type] != null ? sp.jobs[b.type] : 0.5) * (1 + 0.06 * (m.level - 1)) * Math.sqrt(C.RARITY[m.rar].mult);
    if (m.level >= 5) e *= 1.12;
    if (m.evolved) e *= 1.2;
    if (m.trait === "lazy") e *= 0.8; else if (m.trait === "hardworking") e *= 1.2;
    if (m.trait === "intelligent" && b.type === "tower") e *= 1.3;
    return e * D.happyMult * (1 + D.temple);
  };
  S.workEffH = function (h, b) {
    var def = C.HUMAN[h.occ], match = def.site === b.type ? 1 : (h.occ === "adventurer" ? 0.9 : C.HUMAN_MISMATCH);
    return h.prod * match * (0.92 + 0.02 * (h.skills[b.type] || 3)) * (1 + D.mods.hprod);
  };
  S.effOf = function (e, b) { return e.kind === "m" ? S.workEffM(e, b) : S.workEffH(e, b); };
  S.slots = function (b) {
    var def = BUILD[b.type]; if (!def.slots) return 0;
    return def.slots + (b.level - 1) + ((def.cat === "human" || b.type === "tower") ? D.mods.hslots : 0);
  };
  S.lvlMult = function (b) { return 1 + C.LEVEL_OUTPUT * (b.level - 1); };

  /* ---------- derived values ---------- */
  S.recompute = function () {
    var mods = { food: 0, mine: 0, prod: 0, cap: 0, atk: 0, def: 0, squad: 0, sec: 0, den: 0, housing: 0, hprod: 0, hslots: 0, escape: 0, tier: 0, evolve: 0, luck: 0 };
    C.RESEARCH.forEach(function (r) { if (G.research.done[r.id]) for (var k in r.fx) mods[k] = (mods[k] || 0) + r.fx[k]; });
    var cnt = {}, hs = 4 + 2 * (G.castle - 1), pc = 0, sc = 0, sec = 0, temple = 0, tav = 0, bar = 0, smith = 0, hasTrade = 0;
    G.buildings.forEach(function (b) {
      cnt[b.type] = (cnt[b.type] || 0) + 1;
      if (b.type === "house") hs += 4 + 2 * (b.level - 1);
      if (b.type === "prison") { pc += 6 + 3 * (b.level - 1); sec += 0.15 * b.level; }
      if (b.type === "storage") sc += 300 + 150 * (b.level - 1);
      if (b.type === "watchtower") sec += 0.35 * b.level;
      if (b.type === "temple") temple += 0.05 * b.level;
      if (b.type === "tavern") tav += 10 * b.level;
      if (b.type === "barracks") bar += b.level;
      if (b.type === "blacksmith") smith = Math.max(smith, b.level);
      if (b.type === "trading") hasTrade = b.level;
    });
    D.mods = mods; D.cnt = cnt;
    D.housing = Math.floor(hs * (1 + mods.housing));
    D.prisonCap = pc;
    D.cap = Math.round((C.BASE_CAP * (1 + 0.1 * (G.castle - 1)) + sc) * (1 + mods.cap));
    D.sec = sec * (1 + mods.sec);
    D.temple = temple; D.smith = smith; D.trade = hasTrade;
    D.squadCap = C.SQUAD_BASE + bar + mods.squad;
    var loyal = G.monsters.filter(function (m) { return m.trait === "loyal"; }).length;
    D.starving = G.res.food <= 0.01;
    D.hap = clamp(55 + Math.min(30, tav) + Math.min(5, loyal) - (D.starving ? 30 : 0), 0, 100);
    D.happyMult = 0.8 + 0.004 * D.hap;
    D.eatM = 0; G.monsters.forEach(function (m) { D.eatM += SPECIES[m.sp].eat; });
    D.eatH = G.humans.length * C.HUMAN_EAT;
    D.upkeep = 0; G.buildings.forEach(function (b) { if (BUILD[b.type].upkeep) D.upkeep += BUILD[b.type].upkeep * b.level; });
    G.monsters.forEach(function (m) { if (m.trait === "greedy") D.upkeep += 0.3; });
  };

  /* theoretical per-minute rates for the UI (uptime = share of time workers are on site) */
  S.rates = function (uptime) {
    var r = {}; C.RES.forEach(function (k) { r[k] = { prod: 0, cons: 0 }; });
    G.buildings.forEach(function (b) {
      var def = BUILD[b.type]; if (!def.out) return;
      var eff = bEff(b, uptime), lm = S.lvlMult(b);
      for (var k in def.out) r[k].prod += def.out[k] * eff * lm * mult(k);
      if (def.inp) for (var j in def.inp) r[j].cons += def.inp[j] * eff * lm;
    });
    r.food.cons += D.eatM + D.eatH; r.gold.cons += D.upkeep;
    return r;
  };
  S.bRate = function (b, uptime) {
    var def = BUILD[b.type], out = {}; if (!def.out) return null;
    var eff = bEff(b, uptime), lm = S.lvlMult(b);
    for (var k in def.out) out[k] = def.out[k] * eff * lm * mult(k);
    return out;
  };

  function bEff(b, uptime) {
    var eff = 0;
    for (var i = 0; i < b.workers.length; i++) {
      var e = S.ent(b.workers[i]); if (!e || e.away) continue;
      if (uptime == null) { if (e.st !== "working" && e.st !== "inside") continue; eff += S.effOf(e, b); }
      else eff += S.effOf(e, b) * uptime;
    }
    return eff;
  }

  /* ---------- costs ---------- */
  S.canAfford = function (cost) { for (var k in cost) if (G.res[k] < cost[k] - 1e-6) return false; return true; };
  S.pay = function (cost) { for (var k in cost) G.res[k] -= cost[k]; };
  S.gain = function (cost) { for (var k in cost) G.res[k] = Math.min(Math.max(G.res[k], D.cap), G.res[k] + cost[k]); };
  S.buildCost = function (type) {
    var base = BUILD[type].cost, n = D.cnt[type] || 0, o = {};
    for (var k in base) o[k] = Math.ceil(base[k] * (1 + C.COUNT_GROW * n));
    return o;
  };
  S.levelCap = function (b) { var d = BUILD[b.type]; return b.type === "castle" ? C.CASTLE_MAX : Math.min(d.maxLevel, G.castle + 1); };
  S.upCost = function (b) {
    if (b.type === "castle") return C.CASTLE_UP[b.level] ? Object.assign({}, C.CASTLE_UP[b.level].cost) : null;
    var base = BUILD[b.type].cost, o = {}, f = Math.pow(C.UP_BASE, b.level);
    for (var k in base) o[k] = Math.ceil(base[k] * f);
    if (!o.gold) o.gold = Math.round(40 * Math.pow(1.8, b.level));
    return o;
  };
  S.msg = function (ok, m) { return { ok: ok, msg: m }; };

  /* ---------- buildings ---------- */
  S.place = function (type, x, y, rot) {
    var def = BUILD[type];
    if (!def || def.fixed) return S.msg(false, "Can't build that");
    if (def.unlock > G.castle) return S.msg(false, "Needs castle level " + def.unlock);
    if ((D.cnt[type] || 0) >= def.max) return S.msg(false, "Limit reached");
    var pl = W.canPlace(type, x, y, rot, 0); if (!pl.ok) return S.msg(false, pl.reason);
    var cost = S.buildCost(type); if (!S.canAfford(cost)) return S.msg(false, "Not enough resources");
    S.pay(cost);
    var b = { id: G.nid++, type: type, x: x, y: y, rot: rot ? 1 : 0, level: 1, workers: [], acc: {}, t: 0 };
    G.buildings.push(b); W.rebuildOcc(G.buildings); S.recompute();
    S.addLog("Built " + def.name + ".", "good");
    return { ok: true, b: b };
  };
  S.move = function (b, x, y, rot) {
    var pl = W.canPlace(b.type, x, y, rot, b.id); if (!pl.ok) return S.msg(false, pl.reason);
    b.x = x; b.y = y; b.rot = rot ? 1 : 0; b._dv = -1;
    W.rebuildOcc(G.buildings); return { ok: true };
  };
  S.upgrade = function (b) {
    var def = BUILD[b.type];
    if (b.level >= S.levelCap(b)) return S.msg(false, b.type === "castle" ? "Max level" : (b.level >= def.maxLevel ? "Max level" : "Upgrade the castle first"));
    var cost = S.upCost(b); if (!cost) return S.msg(false, "Max level");
    if (b.type === "castle") {
      var cu = C.CASTLE_UP[b.level];
      if (G.monsters.length < cu.pop) return S.msg(false, "Needs " + cu.pop + " monsters");
      for (var i = 0; i < cu.need.length; i++) if (!D.cnt[cu.need[i]]) return S.msg(false, "Needs a " + BUILD[cu.need[i]].name);
    }
    if (!S.canAfford(cost)) return S.msg(false, "Not enough resources");
    S.pay(cost); b.level++;
    if (b.type === "castle") { G.castle = b.level; W.setBounds(G.castle); S.addLog("The Dark Castle is now level " + b.level + ". The village grows!", "good"); }
    else S.addLog(def.name + " upgraded to level " + b.level + ".", "good");
    W.rebuildOcc(G.buildings); S.recompute();
    return { ok: true };
  };
  S.remove = function (b) {
    if (BUILD[b.type].fixed) return S.msg(false, "The castle cannot be removed");
    var idx = G.buildings.indexOf(b); G.buildings.splice(idx, 1); S.recompute();
    if (G.humans.length > D.prisonCap && b.type === "prison") { G.buildings.splice(idx, 0, b); S.recompute(); return S.msg(false, "Too many prisoners for the remaining cells"); }
    if (G.monsters.length > D.housing && b.type === "house") { G.buildings.splice(idx, 0, b); S.recompute(); return S.msg(false, "Not enough beds without it"); }
    b.workers.slice().forEach(function (id) { var e = S.ent(id); if (e) { e.job = null; e.st = "idle"; e.path = null; } });
    var refund = {}; for (var k in BUILD[b.type].cost) refund[k] = Math.floor(BUILD[b.type].cost[k] * C.REFUND);
    S.gain(refund);
    W.rebuildOcc(G.buildings); S.recompute();
    S.addLog("Removed " + BUILD[b.type].name + " (half the cost refunded).");
    return { ok: true };
  };

  /* ---------- workers ---------- */
  S.unassign = function (e) {
    if (e.job) { var b = S.bld(e.job); if (b) b.workers = b.workers.filter(function (i) { return i !== e.id; }); }
    e.job = null; e.st = "idle"; e.path = null; e.carry = null;
  };
  S.assign = function (id, bid) {
    var e = S.ent(id), b = S.bld(bid); if (!e || !b) return S.msg(false, "Missing");
    var def = BUILD[b.type];
    if (e.away) return S.msg(false, "Away on a raid");
    if (!def.slots) return S.msg(false, "No jobs here");
    if (def.kind === "monster" && e.kind === "h") return S.msg(false, "Monsters only");
    if (e.job === bid) return S.msg(false, "Already here");
    if (b.workers.length >= S.slots(b)) return S.msg(false, "No free slots");
    S.unassign(e); b.workers.push(id); e.job = bid; e.st = "idle"; e.path = null;
    return { ok: true };
  };

  /* ---------- monsters ---------- */
  S.recruitCost = function (sp, trait) {
    var c = Object.assign({}, SPECIES[sp].cost), n = G.monsters.length;
    for (var k in c) c[k] = Math.ceil(c[k] * (1 + 0.04 * Math.max(0, n - 4)));
    return c;
  };
  S.recruit = function (sp) {
    var s = SPECIES[sp];
    if (s.unlock > G.castle) return S.msg(false, "Needs castle level " + s.unlock);
    if (G.monsters.length >= D.housing) return S.msg(false, "No free beds. Build a house.");
    var cost = S.recruitCost(sp), m = S.newMonster(sp);
    if (m.trait === "greedy") for (var k in cost) cost[k] = Math.ceil(cost[k] * C.RECRUIT_GREEDY);
    if (!S.canAfford(cost)) { G.monsters.pop(); return S.msg(false, "Not enough resources"); }
    S.pay(cost); S.recompute();
    S.addLog(m.name + " the " + s.name.toLowerCase() + " (" + C.RARITY[m.rar].name + ") joined.", "good");
    return { ok: true, m: m, cost: cost };
  };
  S.dismiss = function (id) {
    var m = S.ent(id); if (!m || m.kind !== "m") return S.msg(false, "Missing");
    if (m.away) return S.msg(false, "Away on a raid");
    S.unassign(m);
    if (m.eq.weapon) G.items.push(m.eq.weapon); if (m.eq.armor) G.items.push(m.eq.armor);
    G.monsters = G.monsters.filter(function (x) { return x.id !== id; });
    S.recompute(); S.addLog(m.name + " was dismissed.");
    return { ok: true };
  };
  S.evolve = function (id) {
    var m = S.ent(id);
    if (!G.research.done.evolution) return S.msg(false, "Research Monster Evolution first");
    if (m.evolved) return S.msg(false, "Already evolved");
    if (m.level < C.EVOLVE_LEVEL) return S.msg(false, "Needs level " + C.EVOLVE_LEVEL);
    if (!S.canAfford(C.EVOLVE_COST)) return S.msg(false, "Not enough resources");
    S.pay(C.EVOLVE_COST); m.evolved = true; G.stats.evolved++;
    S.addLog(m.name + " evolved into a " + C.EVOLVE[m.sp] + "!", "good");
    return { ok: true };
  };
  S.equip = function (mid, itemId) {
    var m = S.ent(mid), i = G.items.findIndex(function (x) { return x.id === itemId; }); if (!m || i < 0) return S.msg(false, "Missing");
    var it = G.items.splice(i, 1)[0];
    if (m.eq[it.slot]) G.items.push(m.eq[it.slot]);
    m.eq[it.slot] = it; return { ok: true };
  };
  S.unequip = function (mid, slot) { var m = S.ent(mid); if (m && m.eq[slot]) { G.items.push(m.eq[slot]); m.eq[slot] = null; } };
  S.makeItem = function (slot, tier, rar) {
    var tbl = slot === "weapon" ? C.WEAPONS : C.ARMORS, t = clamp(tier, 1, 5), base = tbl[t - 1];
    return { id: G.nid++, slot: slot, tier: t, rar: rar, name: base[0], val: Math.round(base[1] * C.RARITY[rar].mult * 10) / 10 };
  };
  S.maxTier = function (slot) { return Math.min(D.smith + 1, G.research.done[slot === "weapon" ? "weapons1" : "armor1"] ? 5 : 2); };
  S.craft = function (slot, tier) {
    var smiths = G.buildings.filter(function (b) { return b.type === "blacksmith" && b.workers.length > 0; });
    if (!smiths.length) return S.msg(false, "A monster must work at a Blacksmith");
    if (tier > S.maxTier(slot)) return S.msg(false, "Tier " + tier + " is not unlocked yet");
    var cost = C.CRAFT_COST(tier); if (!S.canAfford(cost)) return S.msg(false, "Not enough resources");
    S.pay(cost);
    var lv = Math.max.apply(null, smiths.map(function (b) { return b.level; })), rr = R(), rar = rr < 0.04 * lv ? 2 : rr < 0.2 + 0.04 * lv ? 1 : 0;
    var it = S.makeItem(slot, tier, rar); G.items.push(it); G.stats.crafted++;
    S.addLog("Crafted " + it.name + " (+" + it.val + ").", "good");
    return { ok: true, item: it };
  };

  /* ---------- trade ---------- */
  S.price = function (res) { var i = C.RES.indexOf(res); return C.PRICE[res] * (1 + 0.15 * Math.sin(G.time / 300 + i * 1.7)); };
  S.trade = function (res, side) {
    if (!D.trade) return S.msg(false, "Build a Trading Post");
    var lot = C.TRADE_LOT, p = S.price(res) * lot, l = D.trade;
    if (side === "sell") {
      if (G.res[res] < lot) return S.msg(false, "Not enough " + res);
      var gold = Math.floor(p * (0.7 + 0.05 * (l - 1))); G.res[res] -= lot; G.res.gold = Math.min(D.cap, G.res.gold + gold);
      return { ok: true, msg: "Sold " + lot + " " + res + " for " + gold + " gold" };
    }
    var cost = Math.ceil(p * (1.4 - 0.05 * (l - 1)));
    if (G.res.gold < cost) return S.msg(false, "Not enough gold");
    if (G.res[res] + lot > D.cap) return S.msg(false, "Storage would overflow");
    G.res.gold -= cost; G.res[res] += lot;
    return { ok: true, msg: "Bought " + lot + " " + res + " for " + cost + " gold" };
  };

  /* ---------- research ---------- */
  S.canResearch = function (r) {
    if (G.research.done[r.id]) return "done";
    if (G.research.active && G.research.active.id === r.id) return "active";
    if (r.castle > G.castle) return "Castle level " + r.castle;
    for (var i = 0; i < r.req.length; i++) if (!G.research.done[r.req[i]]) return "Needs " + C.RESEARCH.filter(function (x) { return x.id === r.req[i]; })[0].name;
    if (!D.cnt.tower) return "Build a Research Tower";
    if (G.research.active) return "Busy";
    return null;
  };
  S.startResearch = function (id) {
    var r = C.RESEARCH.filter(function (x) { return x.id === id; })[0], why = S.canResearch(r);
    if (why) return S.msg(false, why);
    if (!S.canAfford(r.cost)) return S.msg(false, "Not enough resources");
    S.pay(r.cost); G.research.active = { id: id, left: r.time, total: r.time };
    S.addLog("Research started: " + r.name + ".");
    return { ok: true };
  };
  S.researchSpeed = function (uptime) {
    var sp = 0;
    G.buildings.forEach(function (b) { if (b.type === "tower") sp = Math.max(sp, 1 + 0.25 * (b.level - 1) + 0.35 * bEff(b, uptime)); });
    return sp;
  };

  /* ---------- quests ---------- */
  var Q = {
    goblins: function () { return G.monsters.filter(function (m) { return m.sp === "goblin"; }).length; },
    farm: function () { return D.cnt.farm || 0; }, tavern: function () { return D.cnt.tavern || 0; },
    workers: function () { return G.monsters.concat(G.humans).filter(function (e) { return e.job; }).length; },
    hworkers: function () { return G.humans.filter(function (e) { return e.job; }).length; },
    raids: function () { return G.stats.raids; }, wins: function () { return G.stats.wins; }, captured: function () { return G.stats.captured; },
    adventurers: function () { return G.stats.adventurers; }, crafted: function () { return G.stats.crafted; }, evolved: function () { return G.stats.evolved; },
    farming1: function () { return G.research.done.farming1 ? 1 : 0; }, castle2: function () { return G.castle >= 2 ? 1 : 0; }, castle3: function () { return G.castle >= 3 ? 1 : 0; },
    monsters: function () { return G.monsters.length; }, lvl3: function () { return G.buildings.some(function (b) { return b.level >= 3 && b.type !== "castle"; }) ? 1 : 0; }
  };
  S.qProgress = function (q) { return Math.min(q.goal, Q[q.key]()); };
  S.activeQuests = function () { return C.QUESTS.filter(function (q) { return !G.quests[q.id]; }).slice(0, C.QUEST_ROWS); };
  S.claim = function (qid) {
    var q = C.QUESTS.filter(function (x) { return x.id === qid; })[0];
    if (!q || G.quests[qid] || S.qProgress(q) < q.goal) return S.msg(false, "Not ready");
    G.quests[qid] = 1; S.gain(q.reward);
    S.addLog("Quest complete: " + q.title + ".", "good");
    return { ok: true, q: q };
  };

  /* ---------- the tick ---------- */
  function produce(dt, uptime) {
    G.buildings.forEach(function (b) {
      var def = BUILD[b.type];
      if (def.out) {
        var eff = bEff(b, uptime); b.active = eff > 0; b.starved = false; b.full = false;
        if (eff <= 0) return;
        var lm = S.lvlMult(b), scale = 1, k;
        if (def.inp) {
          for (k in def.inp) { var need = def.inp[k] * eff * lm / 60 * dt; if (need > 0) scale = Math.min(scale, G.res[k] / need); }
          scale = clamp(scale, 0, 1); b.starved = scale < 0.99;
          for (k in def.inp) G.res[k] -= def.inp[k] * eff * lm / 60 * dt * scale;
        }
        for (k in def.out) {
          var amt = def.out[k] * eff * lm * mult(k) / 60 * dt * scale, room = D.cap - G.res[k], g = Math.min(amt, Math.max(0, room));
          if (room <= 0 && amt > 0) b.full = true;
          G.res[k] += g; S.gross[k] = (S.gross[k] || 0) + g;
          if (uptime == null) { b.acc[k] = (b.acc[k] || 0) + g; if (b.acc[k] >= 2.5) { S.pops.push({ bid: b.id, res: k, amt: Math.floor(b.acc[k]) }); b.acc[k] -= Math.floor(b.acc[k]); } }
        }
        for (var i = 0; i < b.workers.length; i++) { var w = S.ent(b.workers[i]); if (w && w.kind === "m" && !w.away && (uptime != null || w.st === "working")) S.addXp(w, 0.03 * dt * (uptime == null ? 1 : uptime)); }
      }
      if (b.type === "training") {
        for (var j = 0; j < b.workers.length; j++) {
          var t = S.ent(b.workers[j]);
          if (t && t.kind === "m" && !t.away && (uptime != null ? true : t.st === "working")) S.addXp(t, 0.2 * (1 + 0.25 * (b.level - 1)) * dt * (uptime == null ? 1 : uptime));
        }
      }
    });
  }

  function upkeep(dt) {
    var f = (D.eatM + D.eatH) / 60 * dt; G.res.food = Math.max(0, G.res.food - f);
    var g = D.upkeep / 60 * dt; G.res.gold = Math.max(0, G.res.gold - g);
    D.starving = G.res.food <= 0.01;
    if (D.starving && (D.eatM + D.eatH) > 0) {
      G.starveT += dt;
      if (G.starveT >= 90) {
        G.starveT = 0;
        var cand = G.monsters.filter(function (m) { return m.trait !== "loyal" && !m.away; });
        if (cand.length > 1) { var m = pick(cand); S.unassign(m); G.monsters = G.monsters.filter(function (x) { return x !== m; }); S.addLog(m.name + " deserted: the village is starving!", "bad"); }
      }
    } else G.starveT = Math.max(0, G.starveT - dt);
  }

  function dens(dt) {
    G.buildings.forEach(function (b) {
      if (b.type !== "den") return;
      b.t += dt * (1 + D.mods.den) * (1 + 0.25 * (b.level - 1));
      if (b.t >= C.DEN_INTERVAL) {
        if (G.monsters.length < D.housing && G.res.food >= 20) {
          b.t = 0; G.res.food -= 20;
          var m = S.newMonster(wpick(C.DEN_POOL), { at: W.doorTile(b), rar: rollRarity() });
          S.recompute(); S.addLog(m.name + " the " + SPECIES[m.sp].name.toLowerCase() + " hatched in the Breeding Den.", "good");
        } else b.t = C.DEN_INTERVAL * 0.9;
      }
    });
  }

  function researchTick(dt, uptime) {
    var a = G.research.active; if (!a) return;
    a.left -= dt * S.researchSpeed(uptime);
    if (a.left <= 0) {
      var r = C.RESEARCH.filter(function (x) { return x.id === a.id; })[0];
      G.research.done[a.id] = true; G.research.active = null; S.recompute();
      S.addLog("Research complete: " + r.name + ".", "good");
    }
  }

  function escapes(offline) {
    var keep = [];
    G.humans.forEach(function (h) {
      if (h.st === "escape") { keep.push(h); return; }
      var p = C.ESCAPE_BASE * h.escape / (1 + D.sec) * (1 - D.mods.escape);
      if (R() < p) {
        G.stats.escapes++;
        S.addLog(h.name + " escaped from the village!", "bad");
        if (offline) { S.unassign(h); return; }
        S.unassign(h); h.st = "escape"; h.path = null; keep.push(h);
      } else keep.push(h);
    });
    G.humans = keep;
  }

  S.tick = function (dt) {
    G.time += dt;
    S.recompute();
    produce(dt, null); upkeep(dt); dens(dt); researchTick(dt, null);
    G.monsters.forEach(function (m) { if (m.hpf < 1 && !m.away) m.hpf = Math.min(1, m.hpf + dt * 0.012); });
    G.escT += dt; if (G.escT >= C.ESCAPE_CHECK) { G.escT = 0; escapes(false); }
    MH.Raid.tick();
  };

  /* ---------- offline ---------- */
  S.offline = function (sec) {
    sec = Math.min(sec, C.OFFLINE_CAP);
    var before = Object.assign({}, G.res), logMark = G.logSeq || 0, step = 30, n = Math.ceil(sec / step), i;
    S.gross = {}; var hum0 = G.humans.length, mon0 = G.monsters.length, esc0 = G.stats.escapes, rd0 = G.stats.raids;
    for (i = 0; i < n; i++) {
      var dt = Math.min(step, sec - i * step);
      G.time += dt; S.recompute();
      produce(dt, C.OFFLINE_UPTIME); upkeep(dt); dens(dt); researchTick(dt, C.OFFLINE_UPTIME);
      G.monsters.forEach(function (m) { if (m.hpf < 1) m.hpf = Math.min(1, m.hpf + dt * 0.012); });
      G.escT += dt; if (G.escT >= C.ESCAPE_CHECK) { G.escT = 0; escapes(true); }
      MH.Raid.tick(true);
    }
    S.recompute();
    var ev = G.log.filter(function (l) { return l.seq > logMark; }).map(function (l) { return l.msg; }).reverse();
    return { seconds: sec, before: before, after: Object.assign({}, G.res), gross: Object.assign({}, S.gross), events: ev.slice(0, 14), moreEvents: Math.max(0, ev.length - 14),
      monsters: G.monsters.length - mon0, escapes: G.stats.escapes - esc0, raids: G.stats.raids - rd0 };
  };

  /* ---------- new game, save, load ---------- */
  var PRE = [["castle", 29, 18], ["house", 24, 22], ["storage", 36, 22], ["prison", 40, 20], ["lumber", 44, 26]];
  function clearFootprints() {
    PRE.forEach(function (p) { var s = BUILD[p[0]].size; for (var y = p[2] - 1; y <= p[2] + s[1] + 1; y++) for (var x = p[1] - 1; x <= p[1] + s[0]; x++) if (W.base[y * C.W + x] === W.T.TREE || W.base[y * C.W + x] === W.T.ROCK) W.base[y * C.W + x] = W.T.GRASS; });
  }
  S.newGame = function () {
    G = S.G = { v: 1, nid: 1, time: 0, saved: Date.now(), seed: 1337, res: Object.assign({}, C.START), buildings: [], monsters: [], humans: [], items: [],
      research: { done: {}, active: null }, quests: {}, stats: { raids: 0, wins: 0, captured: 0, adventurers: 0, crafted: 0, evolved: 0, escapes: 0 },
      log: [], logSeq: 0, reports: [], exps: [], castle: 1, castleId: 0, speed: 1, paused: false, tut: 0, starveT: 0, escT: 0, tutDone: false };
    W.gen(G.seed); clearFootprints(); W.setBounds(1);
    PRE.forEach(function (p) { var b = { id: G.nid++, type: p[0], x: p[1], y: p[2], rot: 0, level: 1, workers: [], acc: {}, t: 0 }; G.buildings.push(b); if (p[0] === "castle") G.castleId = b.id; });
    W.rebuildOcc(G.buildings); S.recompute();
    ["goblin", "goblin", "goblin", "kobold"].forEach(function (sp) { var m = S.newMonster(sp, { rar: 0, trait: pick(["hardworking", "loyal", "brave", "intelligent"]) }); });
    var gm = G.monsters; gm[0].job = null;
    S.recompute();
    S.addLog("Day 1: Four monsters claim a ruined hollow. Build it into a dark kingdom.", "good");
    return G;
  };
  S.save = function () {
    try { G.saved = Date.now(); localStorage.setItem(C.SAVE_KEY, JSON.stringify(G)); return true; } catch (e) { return false; }
  };
  S.hasSave = function () { try { return !!localStorage.getItem(C.SAVE_KEY); } catch (e) { return false; } };
  S.load = function () {
    try {
      var raw = localStorage.getItem(C.SAVE_KEY); if (!raw) return false;
      var o = JSON.parse(raw); if (!o || o.v !== 1 || !o.buildings) return false;
      G = S.G = o;
      W.gen(G.seed); clearFootprints(); W.setBounds(G.castle); W.rebuildOcc(G.buildings);
      G.monsters.forEach(function (m) { m.path = null; if (m.st === "inside" || m.st === "toWork" || m.st === "toStore" || m.st === "toHome" || m.st === "toTavern") m.st = "idle"; });
      G.humans.forEach(function (h) { h.path = null; if (h.st !== "escape" && h.st !== "away") h.st = "idle"; });
      S.recompute(); return true;
    } catch (e) { console.warn("load failed", e); return false; }
  };
  S.wipe = function () { try { localStorage.removeItem(C.SAVE_KEY); } catch (e) {} };
})();
