/* MONSTERHAVEN art: all original, drawn from code. Pixel sprites from letter grids; buildings are procedural. */
(function () {
  "use strict";
  var MH = window.MH, C = MH.C, Art = MH.Art = {};
  var TS = C.TILE;

  var PAL = {
    k: "#1a1410", w: "#f3ecd8", g: "#6bbf59", G: "#3f8a3a", b: "#8a9bb5", B: "#5d6e86",
    c: "#59c9c0", C: "#2f8f8a", h: "#a6efe9", o: "#ece7da", O: "#b9b2a0", p: "#c9c6ee", P: "#9a96d0",
    n: "#9b7653", N: "#6f5236", t: "#c9a47b", y: "#f2d36b", Y: "#c8962a", r: "#d9503f", R: "#8f2f26",
    e: "#1a1410", x: "#a8703a", X: "#6b4426", s: "#8f95a1", S: "#5f6571", m: "#c24a3a", M: "#8a2f26",
    u: "#7a4a8a", U: "#4f2f60", l: "#ffe08a", f: "#d9503f", a: "#c8703a", A: "#8f4a24", v: "#e8dcd0", K: "#3a1f4a", z: "#5a2f70"
  };

  var ROWS = {
    goblin: ["............", "kk........kk", "kgk.kkkk.kgk", ".kgkgggggkgk", "..kgggggggk.", "..kwegggewk.", "..kgggGgggk.", "..kgwkkkwgk.", "...kkgggkk..", "..kNNNNNNk..", "..kNNyyNNk..", "..kkk..kkk.."],
    troll: ["..w......w..", ".kwkkkkkkwk.", ".kbbbbbbbbk.", "kbbbbbbbbbbk", "kbyebbbbeybk", "kbbbbBBbbbbk", "kbwbkkkkbwbk", ".kbbbbbbbbk.", ".kNNNNNNNNk.", "kbNNyyyyNNbk", "kbbkNNNNkbbk", ".kk.kkkk.kk."],
    slime: ["............", "....kkkk....", "...kccccck..", "..kchhcccck.", ".kchhcccccck", ".kccccccccck", "kcceccccecck", "kcceccccecck", "kcccceecccck", "kCCCCCCCCCCk", ".kCCCCCCCCk.", "..kkkkkkkk.."],
    skeleton: ["...kkkkkk...", "..koooooook..", "..koooooook..", "..keeooeek..", "..keeooeek..", "..kookkook..", "...kokokok..", "....kkkkk...", "..kokookok..", "..kookkook..", "..kokookok..", "..kk....kk.."],
    kobold: ["............", "..k......k..", ".kak.kk.kak.", ".kaakaaakaak", "..kaaaaaaak.", "..kayaaayak.", "..kaaaAaaak.", "..kattttaak.", "...kkwwkkk..", "..kAAAAAAk..", "..kAAttAAk..", "..kk....kkk."],
    vampire: ["...kkkkkk...", "..kkkkkkkk..", "..kkvvvvkk..", "..kvvvvvvk..", "..kvrvvrvk..", "..kvvvvvvk..", "..kvvkkvvk..", "...kkvvkk...", ".kzKKKKKKzk.", "kzKKrrrrKKzk", "kzKKKKKKKKzk", ".kkzkkkkzkk."],
    human: ["....kkkk....", "...khhhhk...", "...khhhhk...", "...kssssk...", "...kseesk...", "...kssssk...", "....kkkk....", "..kcccccck..", ".ksccccccsk.", "..kcccccck..", "..kppkkppk..", "..kkk..kkk.."],
    tree: ["....k....", "...kgk...", "..kgggk..", ".kgggGgk.", "kgggggGgk", ".kgGgggk.", "kgggggGgk", "kkkgggkkk", "...kxk...", "...kXk...", "...kkk..."],
    rock: ["....kkkk....", "..kkssssk...", ".kssssSsSk..", "kssssssssSk.", "ksssSssssSSk", "kSSsssssSSSk", ".kkSSSSSSkk."],
    i_gold: ["..kkkk..", ".kYyyyYk", "kYyyyyYk", "kyyYYyyk", "kyyYYyyk", "kYyyyyYk", ".kYYYYk.", "..kkkk.."],
    i_food: ["..kkkk..", ".kffwfk.", "kfwffffk", "kffffwfk", ".kkkkkk.", "...kok..", "...kok..", "...kkk.."],
    i_wood: ["........", "........", ".kkkkkk.", "kyyxxxXk", "kyyxxxXk", ".kkkkkk.", "........", "........"],
    i_stone: ["........", "..kkkk..", ".kssssk.", "kssSsssk", "ksssSssk", ".kSSSSk.", "..kkkk..", "........"],
    i_iron: ["........", "........", "..kkkkk.", ".kwsssSk", "kwssssSk", "kSSSSSSk", ".kkkkkk.", "........"],
    i_essence: ["...kk...", "..kppk..", ".kpppPk.", "kppppPPk", "kppppPPk", ".kpppPk.", "..kPPk..", "...kk..."]
  };
  var HUM = {
    farmer: { c: "#c9a45a", h: "#d9b44a", p: "#6b4a2a" }, miner: { c: "#6a7380", h: "#4a3020", p: "#3a3f48" },
    lumberjack: { c: "#b03a3a", h: "#6a3a20", p: "#4a3a2a" }, craftsman: { c: "#4a78b0", h: "#3a2a20", p: "#5a4a3a" },
    researcher: { c: "#7a4a9a", h: "#c8c8d8", p: "#4a2a6a" }, adventurer: { c: "#b8c0cc", h: "#c04a3a", p: "#4a5058" }
  };
  var ORC = { b: "#6f9a4e", B: "#47682f", N: "#5a4030", y: "#f2d36b" };

  var cache = {}, urls = {};
  function mk(rows, over) {
    var pal = over ? Object.assign({}, PAL, over) : PAL, w = rows[0].length, c = document.createElement("canvas");
    c.width = w; c.height = rows.length;
    var x = c.getContext("2d");
    rows.forEach(function (row, j) {
      if (row.length !== w) console.warn("sprite row length", j, row.length, w);
      for (var i = 0; i < w; i++) { var col = pal[row.charAt(i)]; if (col) { x.fillStyle = col; x.fillRect(i, j, 1, 1); } }
    });
    return c;
  }
  Art.sprite = function (key) {
    if (cache[key]) return cache[key];
    var c;
    if (key === "orc") c = mk(ROWS.troll, ORC);
    else if (key.indexOf("h_") === 0) c = mk(ROWS.human, Object.assign({ s: "#e0b090" }, HUM[key.slice(2)]));
    else c = mk(ROWS[key]);
    return (cache[key] = c);
  };
  Art.icon = function (res) { return Art.sprite("i_" + res); };
  Art.url = function (key, scale) {
    var k = key + "@" + scale;
    if (!urls[k]) {
      var s = Art.sprite(key), o = document.createElement("canvas");
      o.width = s.width * scale; o.height = s.height * scale;
      var x = o.getContext("2d"); x.imageSmoothingEnabled = false; x.drawImage(s, 0, 0, o.width, o.height);
      urls[k] = o.toDataURL();
    }
    return urls[k];
  };
  Art.img = function (key, scale, cls) {
    var s = Art.sprite(key);
    return '<img class="px ' + (cls || "") + '" alt="" width="' + s.width * scale + '" height="' + s.height * scale + '" src="' + Art.url(key, scale) + '">';
  };
  Art.entKey = function (e) { return e.sp ? e.sp : "h_" + e.occ; };

  /* ---------- buildings (procedural) ---------- */
  var STYLE = {
    house: { shape: "hall", wall: "#7b5a4a", wallD: "#4f3628", roof: "#5a2f3a", roofD: "#3f2029", door: "#3a2514", prop: "chimney" },
    storage: { shape: "hall", wall: "#8a7a5a", wallD: "#5a4d36", roof: "#5a5f6b", roofD: "#3f434d", door: "#4a3520", prop: "crates", wide: 1 },
    trading: { shape: "hall", wall: "#8a5a3a", wallD: "#5a3a24", roof: "#b04a3a", roofD: "#7a2f26", door: "#3a2514", prop: "awning" },
    workshop: { shape: "hall", wall: "#6b6f7a", wallD: "#454953", roof: "#4a6a8a", roofD: "#32485f", door: "#3a2514", prop: "gears" },
    tavern: { shape: "hall", wall: "#8a5a3a", wallD: "#5a3a24", roof: "#7a4a8a", roofD: "#4f2f60", door: "#2b1a12", prop: "sign" },
    barracks: { shape: "hall", wall: "#6b5a5a", wallD: "#463a3a", roof: "#8a2f26", roofD: "#5e1d17", door: "#2b1a12", prop: "flags", long: 1 },
    blacksmith: { shape: "hall", wall: "#6b6560", wallD: "#443f3b", roof: "#4a3a34", roofD: "#2f2420", door: "#2b1a12", prop: "forge" },
    alchemist: { shape: "hall", wall: "#5a7a6a", wallD: "#3a5246", roof: "#3f8a6a", roofD: "#2a5f48", door: "#2b1a12", prop: "potion" },
    castle: { shape: "castle", wall: "#6b6580", wallD: "#443f55", roof: "#6a2f8a", roofD: "#431d5a", door: "#1a1410" },
    tower: { shape: "tower", wall: "#6a7088", wallD: "#444a5e", roof: "#3a5fb0", roofD: "#243e78", crystal: "#9fd0ff" },
    watchtower: { shape: "tower", wall: "#7a6a5a", wallD: "#4f4338", roof: "#8a2f26", roofD: "#5e1d17" },
    farm: { shape: "field", soil: "#6a4a2a", crop: "#5f9a3a", crop2: "#d9b44a", wall: "#8a5a3a", wallD: "#5a3a24", roof: "#b04a3a", roofD: "#7a2f26" },
    mine: { shape: "pit", rock: "#7a8090", rockD: "#4f5462" },
    lumber: { shape: "yard", wall: "#8a5a3a", wallD: "#5a3a24", roof: "#4a6a3a", roofD: "#2f4a24" },
    prison: { shape: "pen", wall: "#6a6a72", wallD: "#42424a" },
    training: { shape: "arena" },
    den: { shape: "den" },
    temple: { shape: "temple" },
    gate: { shape: "gate" },
    portal: { shape: "portal" }
  };

  function fr(x, c) { return function (a, b, w, h, col) { x.fillStyle = col; x.fillRect(Math.round(a), Math.round(b), Math.round(w), Math.round(h)); }; }
  var K = "#1a1410";

  var SHAPE = {};
  SHAPE.hall = function (x, f, cw, ch, st, L, tw, th) {
    var wallH = Math.max(14, Math.min(26, Math.round((ch - 16) * 0.5)));
    var roofH = Math.min(ch - wallH - 3, Math.round((ch - 16) * 0.55 + 12));
    var wy = ch - wallH - 2;
    f(1, wy - 1, cw - 2, wallH + 1, K); f(2, wy, cw - 4, wallH - 1, st.wall);
    for (var yy = wy + 3, row = 0; yy < ch - 3; yy += 4, row++) for (var xx = 2 + (row % 2) * 4; xx < cw - 4; xx += 8) f(xx, yy, 3, 1, st.wallD);
    for (var r = 0; r < roofH; r++) {
      var inset = Math.min(Math.round(cw / 2) - 2, Math.round((roofH - r) * 0.55));
      f(inset - 1, wy - roofH + r, cw - inset * 2 + 2, 1, (Math.floor(r / 3) % 2) ? st.roofD : st.roof);
    }
    f(Math.round(cw / 2) - 3, wy - roofH, 6, 1, K); f(0, wy - 1, cw, 1, K);
    var cx = Math.round(cw / 2);
    f(cx - 4, ch - 13, 8, 11, K); f(cx - 3, ch - 12, 6, 10, st.door); f(cx + 1, ch - 7, 1, 1, "#f2d36b");
    var nw = cw >= 48 ? 3 : 2, win = [];
    if (cw >= 40) { win.push(Math.round(cw * 0.2)); win.push(Math.round(cw * 0.78)); }
    else { win.push(cw - 9); }
    if (nw === 3 && cw >= 60) { win.push(Math.round(cw * 0.35)); win.push(Math.round(cw * 0.62)); }
    win.forEach(function (wx) { f(wx - 1, wy + 3, 6, 6, K); f(wx, wy + 4, 4, 4, "#ffe08a"); f(wx + 1, wy + 4, 1, 4, "#c8962a"); });
    if (L >= 2) { f(3, wy - roofH + 2, 1, 8, K); f(4, wy - roofH + 2, 6, 4, "#d9503f"); }
    if (L >= 3) { f(cx - 8, ch - 12, 2, 3, "#ffd25a"); f(cx + 6, ch - 12, 2, 3, "#ffd25a"); }
    if (L >= 4) f(1, wy - 2, cw - 2, 1, "#f2c14e");
    if (L >= 5) { for (var i = 0; i < 3; i++) f(cx - 6 + i * 6, wy - roofH - 4, 2, 4, "#f2c14e"); }
    var P = st.prop;
    if (P === "chimney") { f(cw - 12, wy - roofH + 6, 5, 9, K); f(cw - 11, wy - roofH + 7, 3, 7, "#6a5a50"); f(cw - 11, wy - roofH + 2, 3, 2, "#8a8a95"); }
    if (P === "crates") { f(3, ch - 9, 7, 7, K); f(4, ch - 8, 5, 5, "#a8703a"); f(cw - 11, ch - 8, 7, 6, K); f(cw - 10, ch - 7, 5, 4, "#8a5a2f"); }
    if (P === "awning") { for (var a = 0; a < cw - 4; a += 4) { f(2 + a, wy + 1, 2, 3, "#f3ecd8"); f(4 + a, wy + 1, 2, 3, "#d9503f"); } f(cx - 3, ch - 4, 6, 3, "#a8703a"); }
    if (P === "gears") { f(4, wy + 4, 6, 6, K); f(5, wy + 5, 4, 4, "#aab2bf"); f(6, wy + 6, 2, 2, K); }
    if (P === "sign") { f(cw - 8, wy + 3, 1, 12, K); f(cw - 12, wy + 3, 9, 6, K); f(cw - 11, wy + 4, 7, 4, "#f2d36b"); f(2, ch - 10, 6, 8, K); f(3, ch - 9, 4, 6, "#a8703a"); }
    if (P === "flags") { f(4, wy - roofH - 5, 1, 12, K); f(5, wy - roofH - 5, 7, 4, "#d9503f"); f(cw - 6, wy - roofH - 5, 1, 12, K); f(cw - 13, wy - roofH - 5, 7, 4, "#d9503f"); }
    if (P === "forge") { f(cw - 12, wy - roofH + 5, 6, 12, K); f(cw - 11, wy - roofH + 6, 4, 10, "#5a4f4a"); f(cw - 11, wy - roofH + 2, 4, 3, "#ff8a3a"); f(3, ch - 8, 8, 5, K); f(4, ch - 7, 6, 2, "#5f6571"); }
    if (P === "potion") { f(cw - 12, wy - roofH + 4, 7, 9, K); f(cw - 11, wy - roofH + 5, 5, 7, "#7fe08a"); f(cw - 10, wy - roofH + 2, 3, 3, "#c8f0c8"); }
  };

  SHAPE.castle = function (x, f, cw, ch, st, L) {
    var tw = 14, cx = Math.round(cw / 2);
    f(tw - 2, 16, cw - tw * 2 + 4, ch - 18, K); f(tw - 1, 17, cw - tw * 2 + 2, ch - 20, st.wall);
    for (var yy = 20, row = 0; yy < ch - 4; yy += 4, row++) for (var xx = tw + (row % 2) * 4; xx < cw - tw; xx += 8) f(xx, yy, 3, 1, st.wallD);
    for (var i = 0; i < Math.floor((cw - tw * 2) / 6); i++) f(tw + 1 + i * 6, 13, 4, 4, st.wallD);
    [0, cw - tw].forEach(function (tx) {
      f(tx, 8, tw, ch - 10, K); f(tx + 1, 9, tw - 2, ch - 12, st.wall);
      for (var yy2 = 12; yy2 < ch - 5; yy2 += 4) f(tx + 2, yy2, tw - 4, 1, st.wallD);
      for (var c2 = 0; c2 < 3; c2++) f(tx + 1 + c2 * 5, 5, 3, 4, st.wallD);
      f(tx + 5, 22, 4, 6, K); f(tx + 6, 23, 2, 4, "#ffe08a");
      for (var r = 0; r < 8; r++) f(tx + 1 + r, 5 - r < 0 ? 0 : 5 - r, tw - 2 - r * 2 > 0 ? tw - 2 - r * 2 : 1, 1, st.roof);
      f(tx + tw / 2 - 1, 0, 2, 3, st.roofD);
    });
    f(cx - 6, ch - 20, 12, 18, K); f(cx - 5, ch - 19, 10, 17, "#2b1a12"); f(cx - 5, ch - 19, 10, 3, K);
    for (var d = 0; d < 4; d++) f(cx - 5 + d * 3 + 1, ch - 17, 1, 15, "#4a3520");
    f(cx - 4, 22, 8, 7, K); f(cx - 3, 23, 6, 5, "#ffe08a"); f(cx - 1, 23, 2, 5, "#c8962a");
    f(cx - 10, 19, 4, 10, "#d9503f"); f(cx + 6, 19, 4, 10, "#d9503f");
    if (L >= 2) { f(cx - 1, 4, 2, 10, K); f(cx + 1, 4, 8, 5, "#d9503f"); }
    if (L >= 3) f(tw - 1, 17, cw - tw * 2 + 2, 2, "#f2c14e");
    if (L >= 4) { f(cx - 12, 10, 1, 6, "#ffd25a"); f(cx + 12, 10, 1, 6, "#ffd25a"); }
    if (L >= 5) { f(cx - 3, 0, 6, 3, st.roof); f(cx - 1, -0, 2, 1, "#f2c14e"); }
  };

  SHAPE.tower = function (x, f, cw, ch, st, L, tw) {
    var bx = 4, bw = cw - 8, top = 14, cx = Math.round(cw / 2);
    f(bx - 1, top - 1, bw + 2, ch - top, K); f(bx, top, bw, ch - top - 1, st.wall);
    for (var yy = top + 3, row = 0; yy < ch - 3; yy += 4, row++) for (var xx = bx + 1 + (row % 2) * 3; xx < cw - 6; xx += 6) f(xx, yy, 2, 1, st.wallD);
    for (var i = 0; i * 5 < bw; i++) f(bx + i * 5, top - 4, 3, 4, st.wallD);
    f(cx - 2, top + 5, 5, 7, K); f(cx - 1, top + 6, 3, 5, "#ffe08a");
    f(cx - 3, ch - 11, 7, 10, K); f(cx - 2, ch - 10, 5, 9, "#2b1a12");
    if (st.crystal) { f(cx - 3, 3, 6, 8, K); f(cx - 2, 4, 4, 6, st.crystal); f(cx - 1, 1, 2, 3, "#ffffff"); }
    else for (var r = 0; r < 8; r++) f(cx - 7 + r, 8 - r, 14 - r * 2, 1, (r % 3) ? st.roof : st.roofD);
    if (L >= 2) f(bx, top + 1, bw, 1, "#f2c14e");
    if (L >= 3) { f(bx - 2, top - 2, 2, 4, st.roofD); f(cw - bx, top - 2, 2, 4, st.roofD); }
  };

  SHAPE.field = function (x, f, cw, ch, st, L) {
    f(0, 14, cw, ch - 14, K); f(1, 15, cw - 2, ch - 17, st.soil);
    for (var yy = 21; yy < ch - 6; yy += 5) {
      f(3, yy, cw - 6, 2, (L >= 3 && (yy % 10 === 1)) ? st.crop2 : st.crop);
      f(3, yy - 1, cw - 6, 1, "#7ac257");
    }
    for (var px = 0; px < cw; px += 6) { f(px, 13, 2, 3, "#8a5a2f"); f(px, ch - 4, 2, 3, "#8a5a2f"); }
    f(0, 14, cw, 1, "#a8703a"); f(0, ch - 3, cw, 1, "#a8703a");
    f(cw - 20, 4, 18, 14, K); f(cw - 19, 9, 16, 8, st.wall);
    for (var r = 0; r < 6; r++) f(cw - 20 + r, 3 + (5 - r), 18 - r * 2, 1, (r % 2) ? st.roofD : st.roof);
    f(cw - 14, 11, 5, 6, K);
    f(6, 8, 1, 10, "#8a5a2f"); f(3, 10, 7, 1, "#8a5a2f"); f(5, 5, 3, 3, "#d9b44a");
    if (L >= 2) f(cw - 20, 18, 18, 1, "#f2c14e");
    if (L >= 4) { f(cw - 22, 4, 1, 12, K); f(cw - 24, 4, 3, 3, "#ffd25a"); }
  };

  SHAPE.pit = function (x, f, cw, ch, st, L) {
    var base = ch - 3, hgt = ch - 8, rad = Math.round(cw / 2) - 3, cx = Math.round(cw / 2);
    function dome(r, h, col) { for (var yy = base - h; yy <= base; yy++) { var hw = Math.round(r * Math.sqrt(Math.max(0, 1 - Math.pow((base - yy) / h, 2)))); f(cx - hw, yy, hw * 2 + 1, 1, col); } }
    dome(rad + 1, hgt + 1, K); dome(rad, hgt, st.rock);
    for (var i = 0; i < 40; i++) f(cx - rad + ((i * 37) % (rad * 2)), base - ((i * 13) % hgt), 2, 1, (i % 2) ? st.rockD : "#a0a8b8");
    f(cx - 8, ch - 20, 16, 18, K); f(cx - 7, ch - 19, 14, 17, "#0d0a08");
    f(cx - 9, ch - 21, 2, 19, "#8a5a2f"); f(cx + 7, ch - 21, 2, 19, "#8a5a2f"); f(cx - 9, ch - 22, 18, 3, "#a8703a");
    f(cx - 12, ch - 8, 6, 5, K); f(cx - 11, ch - 7, 4, 3, "#6a4a2a"); f(cx - 11, ch - 3, 2, 2, K); f(cx - 8, ch - 3, 2, 2, K);
    f(cx + 8, ch - 14, 1, 1, "#f2c14e"); f(cx - 14, ch - 18, 1, 1, "#9db4d0"); f(cx + 12, ch - 22, 1, 1, "#9db4d0");
    if (L >= 2) { f(cx - 9, ch - 15, 2, 2, "#ffd25a"); f(cx + 7, ch - 15, 2, 2, "#ffd25a"); }
    if (L >= 3) { for (var rr = 0; rr < Math.floor(cw / 4); rr++) f(2 + rr * 4, ch - 2, 3, 1, "#8a5a2f"); }
  };

  SHAPE.yard = function (x, f, cw, ch, st, L) {
    f(0, 14, cw, ch - 14, "#7a5a3a"); f(0, 14, cw, 1, K); f(0, ch - 2, cw, 1, K);
    for (var i = 0; i < 40; i++) f((i * 29) % (cw - 2) + 1, 16 + ((i * 11) % (ch - 20)), 2, 1, (i % 2) ? "#8f6a3e" : "#6a4a2a");
    for (var s = 0; s < (L >= 3 ? 3 : 2); s++) for (var r = 0; r < 3; r++) { f(3 + s * 11, ch - 16 + r * 4, 10, 4, K); f(4 + s * 11, ch - 15 + r * 4, 8, 2, "#b07a45"); f(4 + s * 11, ch - 15 + r * 4, 2, 2, "#e0b070"); }
    var bx = cw - 22;
    f(bx, 6, 20, 16, K); f(bx + 1, 10, 18, 11, st.wall);
    for (var q = 0; q < 6; q++) f(bx + q, 4 + (5 - q), 20 - q * 2, 1, (q % 2) ? st.roofD : st.roof);
    f(bx + 7, 14, 5, 7, K); f(bx + 2, 12, 4, 4, "#ffe08a");
    f(cw - 28, ch - 12, 1, 8, K); f(cw - 28, ch - 12, 6, 1, "#aab2bf");
    if (L >= 2) f(bx, 21, 20, 1, "#f2c14e");
  };

  SHAPE.pen = function (x, f, cw, ch, st, L) {
    f(0, 12, cw, ch - 12, K); f(1, 13, cw - 2, ch - 15, st.wall);
    for (var yy = 16, row = 0; yy < ch - 3; yy += 4, row++) for (var xx = 2 + (row % 2) * 4; xx < cw - 3; xx += 8) f(xx, yy, 3, 1, st.wallD);
    for (var i = 0; i < Math.floor(cw / 6); i++) { f(3 + i * 6, 6, 2, 8, K); f(3 + i * 6, 4, 2, 3, "#aab2bf"); }
    var cx = Math.round(cw / 2);
    f(cx - 6, ch - 17, 12, 15, K); f(cx - 5, ch - 16, 10, 14, "#3a3a44");
    for (var b = 0; b < 4; b++) f(cx - 4 + b * 3, ch - 15, 1, 12, "#9aa0ad");
    f(cx - 5, ch - 11, 10, 1, "#9aa0ad");
    [Math.round(cw * 0.2), Math.round(cw * 0.7)].forEach(function (wx) { f(wx, 20, 7, 7, K); f(wx + 1, 21, 5, 5, "#14141a"); f(wx + 2, 21, 1, 5, "#9aa0ad"); f(wx + 4, 21, 1, 5, "#9aa0ad"); });
    if (L >= 2) f(1, 12, cw - 2, 1, "#c24a3a");
    if (L >= 3) { f(2, 8, 3, 5, "#c24a3a"); f(cw - 5, 8, 3, 5, "#c24a3a"); }
    if (L >= 4) { f(cx - 3, 14, 6, 3, "#c24a3a"); }
  };

  SHAPE.arena = function (x, f, cw, ch, st, L) {
    f(0, 14, cw, ch - 14, K); f(1, 15, cw - 2, ch - 17, "#c9a870");
    for (var i = 0; i < 50; i++) f((i * 23) % (cw - 4) + 2, 17 + ((i * 7) % (ch - 22)), 2, 1, (i % 2) ? "#b89860" : "#d8b880");
    for (var p = 0; p < cw; p += 6) { f(p, 13, 2, 4, "#8a5a2f"); f(p, ch - 4, 2, 4, "#8a5a2f"); }
    f(0, 15, cw, 1, "#a8703a"); f(0, ch - 3, cw, 1, "#a8703a");
    [Math.round(cw * 0.25), Math.round(cw * 0.6)].forEach(function (dx) { f(dx, 24, 2, 14, "#6a4a2a"); f(dx - 3, 28, 8, 2, "#6a4a2a"); f(dx - 1, 21, 4, 4, "#d9b44a"); f(dx - 1, 21, 4, 1, K); });
    f(cw - 12, 18, 8, 3, K); f(cw - 11, 19, 6, 1, "#aab2bf"); f(cw - 12, 22, 8, 3, K); f(cw - 11, 23, 6, 1, "#aab2bf");
    if (L >= 2) { f(2, 4, 1, 12, K); f(3, 4, 7, 4, "#d9503f"); }
    if (L >= 3) { f(cw - 4, 4, 1, 12, K); f(cw - 11, 4, 7, 4, "#d9503f"); }
  };

  SHAPE.den = function (x, f, cw, ch, st, L) {
    var base = ch - 3, hgt = ch - 12, rad = Math.round(cw / 2) - 3, cx = Math.round(cw / 2);
    function dome(r, h, col) { for (var yy = base - h; yy <= base; yy++) { var hw = Math.round(r * Math.sqrt(Math.max(0, 1 - Math.pow((base - yy) / h, 2)))); f(cx - hw, yy, hw * 2 + 1, 1, col); } }
    dome(rad + 1, hgt + 1, K); dome(rad, hgt, "#7a4a4a");
    for (var i = 0; i < 40; i++) f(cx - rad + ((i * 31) % (rad * 2)), base - ((i * 11) % hgt), 3, 1, (i % 2) ? "#5e3636" : "#9a6060");
    f(cx - 7, ch - 17, 14, 15, K); f(cx - 6, ch - 16, 12, 14, "#2a0f14");
    f(cx - 4, ch - 7, 4, 5, K); f(cx - 3, ch - 6, 2, 3, "#f3ecd8"); f(cx + 1, ch - 8, 4, 6, K); f(cx + 2, ch - 7, 2, 4, "#e8dcd0");
    f(cx - 2, ch - 12, 1, 1, "#ff3a3a"); f(cx + 1, ch - 12, 1, 1, "#ff3a3a");
    f(3, ch - 8, 5, 4, K); f(4, ch - 7, 3, 2, "#c8c0a0");
    if (L >= 2) { f(cx - 10, ch - 14, 2, 2, "#ffd25a"); f(cx + 8, ch - 14, 2, 2, "#ffd25a"); }
    if (L >= 3) f(cx - 7, ch - 18, 14, 1, "#c24a3a");
  };

  SHAPE.temple = function (x, f, cw, ch, st, L) {
    var cx = Math.round(cw / 2), steps = 4 + Math.min(2, L);
    for (var s = 0; s < steps; s++) { var w = cw - 4 - s * 6, y = ch - 4 - (s + 1) * 7; if (w < 8) break; f(cx - w / 2 - 1, y, w + 2, 8, K); f(cx - w / 2, y + 1, w, 6, s % 2 ? "#4a3560" : "#5a4378"); f(cx - w / 2, y + 1, w, 1, "#7a62a0"); }
    f(cx - 3, ch - 14, 6, 11, K); f(cx - 2, ch - 13, 4, 10, "#1a0f24");
    var top = ch - 4 - steps * 7 - 2;
    f(cx - 2, top - 8, 4, 8, "#7a2fb0"); f(cx - 1, top - 12, 2, 5, "#c58cf0"); f(cx, top - 15, 1, 3, "#f0d8ff");
    f(3, ch - 12, 1, 8, "#c58cf0"); f(cw - 4, ch - 12, 1, 8, "#c58cf0");
    if (L >= 2) { f(cx - 8, top + 3, 2, 2, "#c58cf0"); f(cx + 6, top + 3, 2, 2, "#c58cf0"); }
  };

  SHAPE.gate = function (x, f, cw, ch, st, L) {
    var cx = Math.round(cw / 2);
    f(0, 8, 10, ch - 8, K); f(1, 9, 8, ch - 10, "#6a6580"); f(cw - 10, 8, 10, ch - 8, K); f(cw - 9, 9, 8, ch - 10, "#6a6580");
    for (var a = 0; a < 3; a++) { f(1 + a * 3, 5, 2, 4, "#443f55"); f(cw - 9 + a * 3, 5, 2, 4, "#443f55"); }
    f(8, 12, cw - 16, 8, K); f(9, 13, cw - 18, 6, "#6a6580");
    f(10, 20, cw - 20, ch - 22, K);
    for (var yy = 21; yy < ch - 3; yy++) for (var xx = 11; xx < cw - 11; xx++) { var t = ((xx * 7 + yy * 5) % 11); x.fillStyle = t < 3 ? "#5a2f8a" : t < 6 ? "#3a1a5a" : "#210f35"; x.fillRect(xx, yy, 1, 1); }
    f(cx - 1, 15, 2, 2, "#ff3a3a"); f(5, 2, 1, 9, "#c58cf0"); f(cw - 6, 2, 1, 9, "#c58cf0");
  };

  SHAPE.portal = function (x, f, cw, ch, st, L) {
    var cx = Math.round(cw / 2), cy = Math.round(ch / 2) + 2, R = Math.round(Math.min(cw, ch) / 2) - 3;
    for (var yy = -R - 1; yy <= R + 1; yy++) for (var xx = -R - 1; xx <= R + 1; xx++) {
      var d = Math.sqrt(xx * xx + yy * yy);
      if (d <= R + 1.5 && d > R - 3) { x.fillStyle = ((xx + yy) % 3 === 0) ? "#7a8090" : "#5f6571"; x.fillRect(cx + xx, cy + yy, 1, 1); }
      else if (d <= R - 3) { var t = Math.floor(d * 2 + Math.atan2(yy, xx) * 3) % 5; x.fillStyle = t < 1 ? "#d8b0ff" : t < 3 ? "#7a3fd0" : "#3a1a7a"; x.fillRect(cx + xx, cy + yy, 1, 1); }
      else if (d <= R + 2.5) { x.fillStyle = K; x.fillRect(cx + xx, cy + yy, 1, 1); }
    }
    f(cx - 1, cy - R - 4, 2, 3, "#c58cf0"); f(cx - R - 3, cy, 2, 3, "#c58cf0"); f(cx + R + 2, cy, 2, 3, "#c58cf0");
    f(2, ch - 3, cw - 4, 3, "rgba(0,0,0,.28)");
  };

  var bcache = {};
  Art.size = function (type, rot) { var s = C.BUILD[type].size; return rot ? [s[1], s[0]] : [s[0], s[1]]; };
  Art.building = function (type, level, w, h) {
    var key = type + "|" + level + "|" + w + "x" + h;
    if (bcache[key]) return bcache[key];
    var cw = w * TS, ch = h * TS + 16, c = document.createElement("canvas");
    c.width = cw; c.height = ch;
    var x = c.getContext("2d"), f = fr(x), st = STYLE[type] || STYLE.house;
    f(2, ch - 3, cw - 4, 3, "rgba(0,0,0,.28)");
    SHAPE[st.shape](x, f, cw, ch, st, level, w, h);
    return (bcache[key] = c);
  };
  var turls = {};
  Art.thumb = function (type, level, px) {
    var key = type + "|" + level + "|" + px;
    if (turls[key]) return turls[key];
    var s = C.BUILD[type].size, b = Art.building(type, level, s[0], s[1]);
    var o = document.createElement("canvas"); o.width = px; o.height = px;
    var x = o.getContext("2d"); x.imageSmoothingEnabled = false;
    var sc = Math.min(px / b.width, px / b.height), dw = Math.floor(b.width * sc), dh = Math.floor(b.height * sc);
    x.drawImage(b, Math.floor((px - dw) / 2), px - dh, dw, dh);
    return (turls[key] = o.toDataURL());
  };

  /* ---------- terrain ---------- */
  function rng(seed) { return function () { seed |= 0; seed = seed + 0x6D2B79F5 | 0; var t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
  Art.rng = rng;

  Art.paintTerrain = function (Wd) {
    var T = Wd.T, w = C.W, h = C.H, c = document.createElement("canvas");
    c.width = w * TS; c.height = h * TS;
    var x = c.getContext("2d"), R = rng(99), b = Wd.bounds;
    function px(a, b2, col) { x.fillStyle = col; x.fillRect(a, b2, 1, 1); }
    function fill(a, b2, w2, h2, col) { x.fillStyle = col; x.fillRect(a, b2, w2, h2); }
    var tree = Art.sprite("tree"), rock = Art.sprite("rock");
    for (var ty = 0; ty < h; ty++) for (var tx = 0; tx < w; tx++) {
      var t = Wd.terrain[ty * w + tx], X = tx * TS, Y = ty * TS;
      var base = Wd.base[ty * w + tx];
      if (t === T.WATER) {
        fill(X, Y, TS, TS, "#2f6a9a");
        for (var i = 0; i < 14; i++) px(X + Math.floor(R() * TS), Y + Math.floor(R() * TS), R() < 0.5 ? "#4a8fc4" : "#245a86");
        if ((tx + ty) % 3 === 0) fill(X + 3, Y + 6, 5, 1, "#8fc8ec");
        continue;
      }
      if (t === T.BRIDGE) {
        fill(X, Y, TS, TS, "#2f6a9a");
        fill(X, Y + 1, TS, TS - 2, "#8a5a2f");
        for (var p = 0; p < TS; p += 4) fill(X + p, Y + 1, 1, TS - 2, "#5a3a1f");
        fill(X, Y, TS, 1, "#2a1a10"); fill(X, Y + TS - 1, TS, 1, "#2a1a10");
        continue;
      }
      fill(X, Y, TS, TS, "#4c8a3a");
      for (var j = 0; j < 22; j++) px(X + Math.floor(R() * TS), Y + Math.floor(R() * TS), R() < 0.5 ? "#58973f" : "#3f7a31");
      if (R() < 0.35) { var gx = X + Math.floor(R() * 13) + 1, gy = Y + Math.floor(R() * 13) + 2; px(gx, gy, "#7ac257"); px(gx, gy - 1, "#7ac257"); }
      if (R() < 0.06) px(X + Math.floor(R() * TS), Y + Math.floor(R() * TS), R() < 0.5 ? "#f3ecd8" : "#f2d36b");
      if (t === T.ROAD) {
        fill(X, Y, TS, TS, "#a47a4a");
        for (var k = 0; k < 26; k++) px(X + Math.floor(R() * TS), Y + Math.floor(R() * TS), R() < 0.5 ? "#b48a56" : "#8f6a3e");
        var nbr = function (dx, dy) { var q = Wd.terrain[(ty + dy) * w + tx + dx]; return q === T.ROAD || q === T.GATE || q === T.BRIDGE; };
        if (!nbr(0, -1)) fill(X, Y, TS, 1, "#7a5a36"); if (!nbr(0, 1)) fill(X, Y + TS - 1, TS, 1, "#7a5a36");
        if (!nbr(-1, 0)) fill(X, Y, 1, TS, "#7a5a36"); if (!nbr(1, 0)) fill(X + TS - 1, Y, 1, TS, "#7a5a36");
      } else if (t === T.GATE) {
        fill(X, Y, TS, TS, "#a47a4a");
        for (var g = 0; g < 26; g++) px(X + Math.floor(R() * TS), Y + Math.floor(R() * TS), R() < 0.5 ? "#b48a56" : "#8f6a3e");
      } else if (t === T.TREE) {
        x.fillStyle = "rgba(0,0,0,.22)"; x.fillRect(X + 3, Y + 12, 10, 3);
        x.drawImage(tree, X + 3, Y + 4);
      } else if (t === T.ROCK) {
        x.fillStyle = "rgba(0,0,0,.2)"; x.fillRect(X + 1, Y + 11, 14, 3);
        x.drawImage(rock, X + 2, Y + 5);
      }
    }
    /* walls and fences along the playable border */
    function wallTile(tx, ty, kind) {
      var X = tx * TS, Y = ty * TS;
      if (kind === "stone") {
        fill(X, Y + 2, TS, TS - 2, K); fill(X, Y + 3, TS, TS - 5, "#6b6580");
        for (var q = 0; q < TS; q += 8) fill(X + q, Y + 6, 4, 1, "#443f55");
        for (var m = 0; m < TS; m += 8) fill(X + m + 1, Y, 4, 4, "#5a5470");
        fill(X, Y + TS - 3, TS, 3, "rgba(0,0,0,.25)");
      } else {
        fill(X, Y + 5, TS, 2, "#8a5a2f"); fill(X, Y + 10, TS, 2, "#8a5a2f");
        fill(X + 2, Y + 2, 3, 12, "#6a4423"); fill(X + 11, Y + 2, 3, 12, "#6a4423"); fill(X + 2, Y + 2, 3, 1, "#a8703a"); fill(X + 11, Y + 2, 3, 1, "#a8703a");
      }
    }
    for (var wy = 0; wy < h; wy++) for (var wx = 0; wx < w; wx++) {
      if (Wd.terrain[wy * w + wx] !== T.WALL) continue;
      wallTile(wx, wy, wy === b.y0 ? "stone" : "wood");
    }
    var d = Art.building("watchtower", 1, 2, 2);
    Wd.corners.forEach(function (cn) { x.drawImage(d, cn[0] * TS, cn[1] * TS - 16); });
    /* gate pillars flank the south opening */
    [Wd.gateX - 2, Wd.gateX + 2].forEach(function (gx) {
      var X = gx * TS, Y = b.y1 * TS;
      fill(X + 1, Y - 12, 14, 28, K); fill(X + 2, Y - 11, 12, 26, "#6b6580");
      for (var q = Y - 8; q < Y + 14; q += 4) fill(X + 3, q, 10, 1, "#443f55");
      fill(X + 1, Y - 15, 14, 4, "#5a5470"); fill(X + 3, Y - 18, 3, 3, "#5a5470"); fill(X + 10, Y - 18, 3, 3, "#5a5470");
      fill(X + 6, Y - 4, 4, 8, "#d9503f");
    });
    /* outside the playable region: darken */
    x.fillStyle = "rgba(6,4,14,.62)";
    x.fillRect(0, 0, w * TS, b.y0 * TS);
    x.fillRect(0, (b.y1 + 1) * TS, w * TS, (h - b.y1 - 1) * TS);
    x.fillRect(0, b.y0 * TS, b.x0 * TS, (b.y1 - b.y0 + 1) * TS);
    x.fillRect((b.x1 + 1) * TS, b.y0 * TS, (w - b.x1 - 1) * TS, (b.y1 - b.y0 + 1) * TS);
    return c;
  };
})();
