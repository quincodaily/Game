/* MONSTERHAVEN main: boot, game loop, input wiring. */
(function () {
  "use strict";
  var MH = window.MH, C = MH.C, S = MH.Sim, W = MH.World, AI = MH.AI, Rd = MH.Renderer, UI = MH.UI, Raid = MH.Raid;
  function $(id) { return document.getElementById(id); }

  var lastBuildCat = "town", lastMonFilter = "all", rotFlag = false;

  function doAction(act, ds) {
    switch (act) {
      case "tab-build": UI.openTab("build", { cat: lastBuildCat }); break;
      case "tab-monsters": UI.openTab("monsters", { filter: lastMonFilter }); break;
      case "tab-humans": UI.openTab("humans"); break;
      case "tab-military": UI.openTab("military"); break;
      case "tab-research": UI.openTab("research"); break;
      case "quest-open": UI.openTab("quests"); break;
      case "sheet-close": UI.closeSheet(); break;
      case "close-modal": UI.closeModal(); break;
      case "build-cat": lastBuildCat = ds.cat; UI.openTab("build", { cat: ds.cat }); break;
      case "build-pick": startPlacement(ds.type); break;
      case "place-rotate": { rotFlag = !rotFlag; var pm = Rd.getPlaceMode(); if (pm) pm.rot = rotFlag; break; }
      case "place-cancel": Rd.setPlaceMode(null); UI.placeBar(null); break;
      case "mon-filter": lastMonFilter = ds.f; UI.openTab("monsters", { filter: ds.f }); break;
      case "recruit": { var r = S.recruit(ds.sp); UI.toast(r.ok ? "Recruited!" : r.msg, !r.ok); UI.refreshAll(); break; }
      case "open-ent": UI.openEnt(parseInt(ds.id, 10)); break;
      case "assign": { var r2 = S.assign(parseInt(ds.m, 10), parseInt(ds.b, 10)); if (!r2.ok) UI.toast(r2.msg, true); UI.refreshAll(); break; }
      case "unassign": { var m = S.ent(parseInt(ds.m, 10)); if (m) S.unassign(m); UI.refreshAll(); break; }
      case "dismiss": UI.confirm("Dismiss this monster? This can't be undone.", '<button class="pbtn danger" data-act="dismiss-ok" data-m="' + ds.m + '">Dismiss</button>'); break;
      case "dismiss-ok": S.dismiss(parseInt(ds.m, 10)); UI.closeModal(); UI.closeSheet(); UI.refreshAll(); break;
      case "evolve": { var r3 = S.evolve(parseInt(ds.m, 10)); if (!r3.ok) UI.toast(r3.msg, true); else UI.toast("Evolved!"); UI.refreshAll(); break; }
      case "equip": S.equip(parseInt(ds.m, 10), parseInt(ds.i, 10)); UI.refreshAll(); break;
      case "unequip": S.unequip(parseInt(ds.m, 10), ds.slot); UI.refreshAll(); break;
      case "open-bld": UI.openBld(parseInt(ds.id, 10)); break;
      case "upgrade": { var r5 = S.upgrade(S.bld(parseInt(ds.b, 10))); if (!r5.ok) UI.toast(r5.msg, true); else UI.toast("Upgraded!"); UI.refreshAll(); break; }
      case "move-bld": startMove(parseInt(ds.b, 10)); break;
      case "remove-bld": UI.confirm("Remove this building? Half the cost is refunded.", '<button class="pbtn danger" data-act="remove-ok" data-b="' + ds.b + '">Remove</button>'); break;
      case "remove-ok": { var rb = S.remove(S.bld(parseInt(ds.b, 10))); if (!rb.ok) UI.toast(rb.msg, true); UI.closeModal(); UI.closeSheet(); UI.refreshAll(); break; }
      case "craft": { var r6 = S.craft(ds.slot, parseInt(ds.t, 10)); if (!r6.ok) UI.toast(r6.msg, true); else UI.toast("Crafted!"); UI.refreshAll(); break; }
      case "trade": { var r7 = S.trade(ds.res, ds.side); UI.toast(r7.ok ? r7.msg : r7.msg, !r7.ok); UI.refreshAll(); break; }
      case "research": { var r8 = S.startResearch(ds.id); if (!r8.ok) UI.toast(r8.msg, true); UI.refreshAll(); break; }
      case "claim": { var r9 = S.claim(ds.q); if (!r9.ok) UI.toast(r9.msg, true); else UI.toast("Reward claimed!"); UI.refreshAll(); break; }
      case "raid-open": UI.openCamp(ds.t); break;
      case "raid-back": UI.openTab("military"); break;
      case "raid-pick": UI.togglePick(ds.m); break;
      case "raid-send": { var r10 = UI.sendRaid(ds.t); UI.toast(r10.ok ? "Squad sent!" : r10.msg, !r10.ok); UI.openTab("military"); UI.refreshAll(); break; }
      case "recall": Raid.recall(parseInt(ds.e, 10)); UI.refreshAll(); break;
      case "report-open": UI.openReport(parseInt(ds.r, 10)); break;
      case "speed": setSpeed(parseInt(ds.v, 10)); break;
      case "pause": togglePause(); break;
      case "tut-next": tutorialNext(); break;
      case "center": Rd.centerOnCastle(); break;
      case "wipe": UI.confirm("Erase your kingdom and start a new game? This cannot be undone.", '<button class="pbtn danger" data-act="wipe-ok">Erase</button>'); break;
      case "wipe-ok": S.wipe(); location.reload();
    }
  }

  function startPlacement(type) {
    UI.closeSheet(); rotFlag = false;
    Rd.setPlaceMode({ type: type, rot: false });
    UI.placeBar({ type: type });
  }
  function startMove(bid) {
    var b = S.bld(bid);
    UI.closeSheet(); rotFlag = !!b.rot;
    Rd.setPlaceMode({ type: b.type, rot: !!b.rot, movingId: bid, moving: b });
    UI.placeBar({ type: b.type });
  }
  function onMapTap(sel) {
    if (!sel) { UI.closeSheet(); return; }
    if (sel.type === "ent") UI.openEnt(sel.id);
    else if (sel.type === "bld") UI.openBld(sel.id);
    else if (sel.type === "camp") UI.openCamp(sel.id);
  }
  function onMapPlace() {
    var pm = Rd.getPlaceMode(); if (!pm || !pm.at || pm.valid === false) return;
    if (pm.movingId) {
      var r = S.move(pm.moving, pm.at[0], pm.at[1], pm.rot);
      if (r.ok) { UI.toast("Moved"); Rd.setPlaceMode(null); UI.placeBar(null); UI.refreshAll(); } else UI.toast(r.msg, true);
    } else {
      var r2 = S.place(pm.type, pm.at[0], pm.at[1], pm.rot);
      if (r2.ok) { UI.toast(C.BUILD[pm.type].name + " built!"); Rd.setPlaceMode(null); UI.placeBar(null); UI.refreshAll(); }
      else UI.toast(r2.msg, true);
    }
  }

  function setSpeed(v) { S.G.speed = v; UI.hud(); }
  function togglePause() { S.G.paused = !S.G.paused; UI.hud(); }

  function tutorialNext() {
    var G = S.G;
    if (G.tut < C.TUTORIAL.length - 1) { G.tut++; var s = C.TUTORIAL[G.tut]; UI.tutorialModal(G.tut, C.TUTORIAL.length, s[0], s[1]); }
    else { G.tutDone = true; UI.closeModal(); S.save(); }
  }
  function startTutorial() { S.G.tut = 0; var s = C.TUTORIAL[0]; UI.tutorialModal(0, C.TUTORIAL.length, s[0], s[1]); }

  var cv, raf, last = 0, autosaveT = 0, sheetPoll = 0;

  function boot() {
    cv = $("gameCanvas");
    Rd.init(cv);
    var loaded = S.hasSave() && S.load();
    if (!loaded) S.newGame();
    W.rebuildOcc(S.G.buildings); AI.reset(); S.recompute();
    Rd.centerOnCastle();
    Rd.setHandlers({ tap: onMapTap, place: onMapPlace });
    wireButtons(); buildTabBar();
    if (!S.G.tutDone) startTutorial();
    else {
      var offSec = Math.max(0, (Date.now() - S.G.saved) / 1000);
      if (offSec > 20) { var rep = S.offline(offSec); if (Object.keys(rep.gross).length || rep.events.length) UI.offlineModal(rep); }
    }
    UI.refreshAll();
    last = performance.now();
    raf = requestAnimationFrame(loop);
  }

  function wireButtons() {
    document.body.addEventListener("click", function (e) {
      var t = e.target.closest("[data-act]"); if (!t) return;
      doAction(t.dataset.act, t.dataset);
    });
    /* checkbox 'change' is covered by the click delegation above; no separate handler needed */
  }
  function buildTabBar() {
    var bar = $("tabBar");
    [["build", "Build"], ["monsters", "Monsters"], ["humans", "Humans"], ["military", "Military"], ["research", "Research"]].forEach(function (t) {
      var b = document.createElement("button"); b.className = "tabbtn"; b.type = "button"; b.dataset.act = "tab-" + t[0]; b.textContent = t[1];
      bar.appendChild(b);
    });
  }

  function loop(ts) {
    raf = requestAnimationFrame(loop);
    var dt = Math.min(0.25, (ts - last) / 1000); last = ts;
    UI.tickToast(dt);
    if (!S.G.paused) { var simDt = dt * S.G.speed; S.tick(simDt); AI.update(simDt); }
    S.pops.length = 0;
    Rd.frame();
    sheetPoll += dt;
    if (sheetPoll > 0.5) { sheetPoll = 0; if (UI.isOpen()) UI.refreshSheet(); }
    UI.hud(); UI.quests();
    autosaveT += dt; if (autosaveT >= C.AUTOSAVE) { autosaveT = 0; S.save(); }
  }

  window.addEventListener("beforeunload", function () { if (S.G) S.save(); });
  document.addEventListener("visibilitychange", function () { if (document.hidden && S.G) S.save(); });

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
})();
