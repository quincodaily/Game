/* MONSTERHAVEN NPC behaviour: walk, work, deliver, rest, visit the tavern. Everything moves along A* paths. */
(function () {
  "use strict";
  var MH = window.MH, C = MH.C, W = MH.World, S = MH.Sim;
  var AI = MH.AI = {};
  var INDOOR = { trading: 1, workshop: 1, blacksmith: 1, alchemist: 1, tower: 1, temple: 1 };

  function R() { return Math.random(); }
  function door(b) { if (b._dv !== W.version) { b._d = W.doorTile(b); b._dv = W.version; } return b._d; }
  AI.door = door;

  function nearestOf(type, e) {
    var G = S.G, best = null, bd = 1e9;
    G.buildings.forEach(function (b) {
      if (type && b.type !== type) return;
      var d = Math.abs(b.x - e.px) + Math.abs(b.y - e.py);
      if (d < bd) { bd = d; best = b; }
    });
    return best;
  }
  function goTo(e, tile, st) {
    var p = W.path(Math.floor(e.px), Math.floor(e.py), tile[0], tile[1]);
    if (!p) { e.st = "idle"; e.wait = 2 + R() * 3; e.path = null; return false; }
    e.path = p; e.dest = tile; e.st = st; e.pv = W.version;
    return true;
  }
  function speedOf(e) { return e.kind === "m" ? 2.6 * (MH.C.SPECIES[e.sp].speed || 1) : 1.9; }

  function wander(e, around, radius) {
    var cx = around[0] + Math.round((R() * 2 - 1) * radius), cy = around[1] + Math.round((R() * 2 - 1) * radius);
    var t = W.nearestWalkable(cx, cy, 4); if (!t) { e.wait = 2; return; }
    if (!goTo(e, t, "wander")) return;
  }

  function homeFor(e) {
    if (e.kind === "h") return nearestOf("prison", e) || nearestOf("castle", e);
    return nearestOf("house", e) || nearestOf("castle", e);
  }
  function storageFor(e) { return nearestOf("storage", e) || nearestOf("castle", e); }

  function decide(e) {
    var G = S.G;
    if (e.wait > 0) return;
    var b = e.job ? S.bld(e.job) : null;
    if (e.job && !b) { e.job = null; }
    if (e.energy < 20) { var h = homeFor(e); if (h && goTo(e, door(h), "toHome")) return; e.energy = 40; }
    if (b) { goTo(e, door(b), "toWork"); return; }
    if (e.kind === "m" && S.D.cnt.tavern && R() < 0.3) { var tv = nearestOf("tavern", e); if (tv && goTo(e, door(tv), "toTavern")) return; }
    var home = e.kind === "h" ? (nearestOf("prison", e) || nearestOf("castle", e)) : (R() < 0.5 ? nearestOf("castle", e) : (nearestOf("house", e) || nearestOf("castle", e)));
    wander(e, door(home), e.kind === "h" ? 2 : 4);
  }

  function arrive(e) {
    var b;
    switch (e.st) {
      case "toWork":
        b = e.job ? S.bld(e.job) : null;
        if (!b) { e.st = "idle"; break; }
        if (INDOOR[b.type]) { e.st = "inside"; e.vis = false; e.inKind = "work"; e.wait = 9999; }
        else { e.st = "working"; e.wait = 12 + R() * 12; var d = door(b); e.px = d[0] + 0.5 + ((e.id % 5) - 2) * 0.16; e.py = d[1] + 0.3; }
        break;
      case "toStore": e.st = "storing"; e.wait = 0.5; break;
      case "toHome": e.st = "inside"; e.vis = false; e.inKind = "rest"; e.wait = 9999; break;
      case "toTavern": e.st = "inside"; e.vis = false; e.inKind = "tavern"; e.wait = 6 + R() * 5; break;
      case "wander": e.st = "idle"; e.wait = 2 + R() * 5; break;
      case "toGate":
        e.st = "away"; e.vis = false; break;
      case "escape":
        var G = S.G; G.humans = G.humans.filter(function (h) { return h !== e; }); break;
      default: e.st = "idle";
    }
  }

  function move(e, dt) {
    if (!e.path || !e.path.length) { arrive(e); return; }
    if (e.pv !== W.version) {
      e.pv = W.version;
      var nx = e.path[0];
      if (!W.walkable(nx[0], nx[1])) { if (!goTo(e, e.dest, e.st)) return; }
    }
    var t = e.path[0], tx = t[0] + 0.5, ty = t[1] + 0.5, dx = tx - e.px, dy = ty - e.py, d = Math.sqrt(dx * dx + dy * dy), step = speedOf(e) * dt;
    if (dx) e.face = dx < 0;
    e.walk = (e.walk || 0) + dt;
    if (d <= step) { e.px = tx; e.py = ty; e.path.shift(); if (!e.path.length) arrive(e); }
    else { e.px += dx / d * step; e.py += dy / d * step; }
  }

  AI.step = function (e, dt) {
    if (e.away && e.st !== "toGate") { e.vis = false; return; }
    if (e.st === "away") { e.vis = false; return; }
    e.vis = e.st !== "inside";
    if (e.wait > 0 && e.st !== "inside" && e.st !== "working") e.wait -= dt;
    switch (e.st) {
      case "idle":
        if (e.kind === "h" && e.st === "escape") break;
        decide(e); break;
      case "toWork": case "toStore": case "toHome": case "toTavern": case "wander": case "escape": case "toGate":
        if (!e.path && e.st === "toGate") { var g = W.gateTile(); if (!goTo(e, g, "toGate")) { e.st = "away"; } break; }
        if (!e.path && e.st === "escape") { if (!goTo(e, W.gateTile(), "escape")) { S.G.humans = S.G.humans.filter(function (h) { return h !== e; }); } break; }
        move(e, dt); break;
      case "storing":
        if (e.wait <= 0) { e.carry = null; var b = e.job ? S.bld(e.job) : null; if (b) goTo(e, door(b), "toWork"); else e.st = "idle"; }
        break;
      case "working":
        e.wait -= dt; e.energy -= (e.kind === "m" ? 0.25 : 0.2) * dt;
        if (e.energy < 15) { e.st = "idle"; e.wait = 0; break; }
        if (e.wait <= 0) {
          var wb = e.job ? S.bld(e.job) : null;
          if (wb && C.BUILD[wb.type].out) {
            var out = Object.keys(C.BUILD[wb.type].out)[0], st = storageFor(e);
            if (st && goTo(e, door(st), "toStore")) { e.carry = out; break; }
          }
          e.wait = 12 + R() * 12;
        }
        break;
      case "inside":
        if (e.inKind === "rest") {
          e.energy = Math.min(100, e.energy + 4 * dt);
          if (e.energy >= 85) { e.st = "idle"; e.wait = 0; var h = homeFor(e); if (h) { var d = door(h); e.px = d[0] + 0.5; e.py = d[1] + 0.5; } }
        } else if (e.inKind === "tavern") {
          e.energy = Math.min(100, e.energy + 6 * dt); e.wait -= dt;
          if (e.wait <= 0) { e.st = "idle"; e.wait = 1; var tv = nearestOf("tavern", e); if (tv) { var td = door(tv); e.px = td[0] + 0.5; e.py = td[1] + 0.5; } }
        } else e.energy = Math.max(30, e.energy - 0.05 * dt);
        if (e.inKind === "work" && !e.job) { e.st = "idle"; e.wait = 0; }
        break;
      default: e.st = "idle";
    }
  };

  AI.update = function (dt) {
    var G = S.G;
    G.monsters.forEach(function (m) { AI.step(m, dt); });
    G.humans.slice().forEach(function (h) { AI.step(h, dt); });
  };

  /* after loading or offline progress: put workers at their sites without walking */
  AI.reset = function () {
    var G = S.G;
    G.monsters.concat(G.humans).forEach(function (e) {
      if (e.away || e.st === "away") return;
      e.path = null; e.carry = null; e.wait = Math.random() * 3;
      var b = e.job ? S.bld(e.job) : null;
      if (b) {
        var d = door(b); e.px = d[0] + 0.5; e.py = d[1] + 0.5;
        if (INDOOR[b.type]) { e.st = "inside"; e.inKind = "work"; e.vis = false; } else { e.st = "working"; e.wait = 12 + R() * 12; e.vis = true; }
      } else {
        var t = W.nearestWalkable(Math.floor(e.px), Math.floor(e.py), 8);
        if (t) { e.px = t[0] + 0.5; e.py = t[1] + 0.5; }
        if (e.st !== "escape") e.st = "idle";
        e.vis = true;
      }
    });
  };
})();
