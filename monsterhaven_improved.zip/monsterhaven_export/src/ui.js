/* MONSTERHAVEN UI: HUD, bottom tabs, sliding sheet panels, modals. Plain DOM, rebuilt on each refresh() call. */
(function () {
  "use strict";
  var MH = window.MH, C = MH.C, S = MH.Sim, W = MH.World, Art = MH.Art, Rd = MH.Renderer, Raid = MH.Raid;
  var UI = MH.UI = {};
  function $(id) { return document.getElementById(id); }
  function el(tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
  function esc(s) { return String(s).replace(/[&<>]/g, function (c) { return c === "&" ? "&amp;" : c === "<" ? "&lt;" : "&gt;"; }); }
  /* only touch the DOM when the markup really changed: rewriting it every frame swallows taps that land mid-rewrite */
  function setHtml(node, html) { if (node.__html !== html) { node.__html = html; node.innerHTML = html; } }
  function pct(v) { return Math.round(v * 100); }
  function n1(v) { return Math.round(v * 10) / 10; }

  var sheet = null, sheetMode = null, toast = null, toastT = 0, speedSave;
  var raidPick = {}, curTerrId = null;

  /* ---------- resource chips ---------- */
  function resChip(res, rate) {
    var G = S.G, v = Math.floor(G.res[res]), cap = S.D.cap, near = v >= cap * 0.95;
    var r = rate ? rate[res] : null, net = r ? r.prod - r.cons : 0;
    var sub = r ? (net >= 0 ? "+" : "−") + n1(Math.abs(net)) + "/m" : "";
    return '<div class="rchip' + (near ? " full" : "") + '">' + Art.img("i_" + res, 2) + '<span class="rv">' + v + '</span>' + (sub ? '<span class="rs ' + (net >= 0 ? "pos" : "neg") + '">' + sub + "</span>" : "") + "</div>";
  }

  var hudH = 0;
  UI.hud = function () {
    var G = S.G, rate = S.rates(1);
    setHtml($("hud-res"), ["gold", "food", "wood", "stone", "iron", "essence"].map(function (r) { return resChip(r, rate); }).join(""));
    $("hud-castle").textContent = "Castle Lv" + G.castle + " · Day " + (Math.floor(G.time / C.DAY_LEN) + 1);
    var pop = $("hud-pop"); pop.textContent = G.monsters.length + "/" + S.D.housing;
    pop.className = "pop" + (G.monsters.length >= S.D.housing ? " full" : "");
    var hum = $("hud-hum"); hum.textContent = G.humans.filter(function (h) { return h.st !== "escape"; }).length + "/" + S.D.prisonCap;
    setHtml($("hud-hap"), "Mood " + Math.round(S.D.hap) + "%" + (S.D.starving ? ' <span class="warnText">Starving!</span>' : ""));
    var speeds = $("speedRow"); if (speeds) Array.prototype.forEach.call(speeds.children, function (b, i) { b.setAttribute("aria-pressed", String(C.SPEEDS[i] === G.speed)); });
    var pb = $("pauseBtn"); if (pb) pb.setAttribute("aria-pressed", String(G.paused));
    var h = $("hud").offsetHeight; if (h !== hudH) { hudH = h; document.documentElement.style.setProperty("--hud-h", h + "px"); }   // toasts sit just under the HUD, however tall it wraps
  };

  UI.toast = function (msg, bad) { toast = { msg: msg, bad: bad }; toastT = 2.4; renderToast(); };
  function renderToast() {
    var t = $("toast"); if (!t) return;
    if (!toast) { t.hidden = true; return; }
    t.hidden = false; t.textContent = toast.msg; t.className = "toast" + (toast.bad ? " bad" : "");
  }
  UI.tickToast = function (dt) { if (toastT > 0) { toastT -= dt; if (toastT <= 0) { toast = null; renderToast(); } } };

  /* ---------- quest tracker (floating) ---------- */
  UI.quests = function () {
    var box = $("questMini"); var list = S.activeQuests();
    setHtml(box, list.map(function (q) {
      var p = S.qProgress(q), done = p >= q.goal;
      return '<div class="qrow' + (done ? " done" : "") + '" data-act="' + (done ? "claim" : "quest-open") + '" data-q="' + q.id + '"><span class="qt">' + esc(q.title) + '</span><span class="qp">' + (done ? "Claim!" : p + "/" + q.goal) + "</span></div>";
    }).join("") || '<div class="qrow done">All current quests complete!</div>');
  };

  /* ---------- sheet plumbing ---------- */
  function openSheet(mode, data) { sheetMode = mode; sheet = data || {}; renderSheet(); $("sheetWrap").classList.add("open"); }
  function closeSheet() { $("sheetWrap").classList.remove("open"); sheetMode = null; Rd.setSelection(null); Rd.setPlaceMode(null); UI.placeBar(null); }
  UI.closeSheet = closeSheet;
  UI.isOpen = function () { return !!sheetMode; };
  UI.refreshSheet = function () { if (sheetMode) renderSheet(); };
  var pressing = false;
  ["#sheetWrap", "#questMini"].forEach(function (sel) {
    var n = document.querySelector(sel); if (!n) return;
    n.addEventListener("pointerdown", function () { pressing = true; });
  });
  ["pointerup", "pointercancel"].forEach(function (ev) { window.addEventListener(ev, function () { setTimeout(function () { pressing = false; }, 0); }); });
  /* the 2-per-second background refresh: never repaint under a finger that is mid-tap */
  UI.pollSheet = function () { if (sheetMode && !pressing) renderSheet(); };

  function renderSheet() {
    var body = $("sheetBody"), title = $("sheetTitle");
    var fn = SHEETS[sheetMode]; if (!fn) { closeSheet(); return; }
    var r = fn(sheet);
    title.textContent = r.title;
    setHtml(body, r.html);
  }

  /* ---------- cost / rarity helpers ---------- */
  function costRow(cost) {
    return '<div class="costs">' + Object.keys(cost).map(function (k) {
      var short = S.G.res[k] < cost[k];
      return '<span class="cost' + (short ? " short" : "") + '">' + Art.img("i_" + k, 1) + Math.ceil(cost[k] * 10) / 10 + "</span>";
    }).join("") + "</div>";
  }
  function rarTag(rar) { var r = C.RARITY[rar]; return '<span class="rar" style="color:' + r.color + '">' + r.name + "</span>"; }
  function barPx(v, max, color) { return '<span class="pbar"><i style="width:' + Math.max(0, Math.min(100, (v / max) * 100)) + "%;background:" + color + '"></i></span>'; }

  /* ================= BUILD ================= */
  function buildTab(cat) {
    cat = cat || "town";
    var cats = C.BUILD_CATS.map(function (c) { return '<button class="chiptab" data-act="build-cat" data-cat="' + c[0] + '" aria-pressed="' + (c[0] === cat) + '">' + c[1] + "</button>"; }).join("");
    var rows = Object.keys(C.BUILD).filter(function (k) { return C.BUILD[k].cat === cat && !C.BUILD[k].fixed; }).map(function (k) {
      var def = C.BUILD[k], locked = def.unlock > S.G.castle, atMax = (S.D.cnt[k] || 0) >= def.max;
      var cost = S.buildCost(k), dis = locked || atMax;
      return '<div class="bcard2' + (dis ? " locked" : "") + '"><div class="bc-top"><img class="px" src="' + Art.thumb(k, 1, 56) + '" width="56" height="56"><div class="bc-info"><h4>' + def.name + '</h4><p>' + def.desc + "</p></div></div>" +
        (locked ? '<p class="note warn">Needs castle level ' + def.unlock + "</p>" : atMax ? '<p class="note warn">Limit reached (' + def.max + ")</p>" : costRow(cost)) +
        '<button class="pbtn ' + (dis || !S.canAfford(cost) ? "" : "go") + '" type="button" data-act="build-pick" data-type="' + k + '"' + (dis ? " disabled" : "") + ">Place</button></div>";
    }).join("");
    return '<div class="chiptabs">' + cats + '</div><div class="stack">' + rows + "</div>";
  }

  /* ================= MONSTERS ================= */
  function traitLine(m) { var t = C.TRAITS[m.trait]; return '<span class="trait' + (t.good ? " good" : " bad") + '">' + t.name + "</span>"; }
  function monsterRow(m) {
    var sp = C.SPECIES[m.sp], jb = m.job ? S.bld(m.job) : null;
    return '<div class="erow" data-act="open-ent" data-id="' + m.id + '"><div class="eport">' + Art.img(m.sp, 2) + "</div><div class=\"ebody\"><h4>" + esc(m.name) + " <small>Lv" + m.level + "</small></h4>" +
      '<p>' + sp.name + (m.evolved ? " → " + C.EVOLVE[m.sp] : "") + " &middot; " + rarTag(m.rar) + " &middot; " + traitLine(m) + "</p>" +
      '<p class="sub2">' + (m.away ? "On a raid" : jb ? "Working: " + C.BUILD[jb.type].name : "Idle") + (m.hpf < 0.99 ? " &middot; HP " + pct(m.hpf) + "%" : "") + "</p></div><span class=\"chev\">›</span></div>";
  }
  function monstersTab(filter) {
    filter = filter || "all";
    var G = S.G, list = G.monsters.slice().sort(function (a, b) { return b.rar - a.rar || b.level - a.level; });
    if (filter !== "all") list = list.filter(function (m) { return m.sp === filter; });
    var tabs = ['<button class="chiptab" data-act="mon-filter" data-f="all" aria-pressed="' + (filter === "all") + '">All (' + G.monsters.length + ")</button>"]
      .concat(Object.keys(C.SPECIES).map(function (k) { var c = G.monsters.filter(function (m) { return m.sp === k; }).length; return '<button class="chiptab" data-act="mon-filter" data-f="' + k + '" aria-pressed="' + (filter === k) + '">' + C.SPECIES[k].name + " (" + c + ")</button>"; }));
    var recruit = Object.keys(C.SPECIES).map(function (k) {
      var sp = C.SPECIES[k], locked = sp.unlock > G.castle, cost = S.recruitCost(k);
      return '<button class="rbtn' + (locked ? " locked" : "") + '" type="button" data-act="recruit" data-sp="' + k + '"' + (locked ? " disabled" : "") + '>' + Art.img(k, 2) + "<b>" + sp.name + "</b>" + (locked ? "Lv" + sp.unlock : costRow(cost)) + "</button>";
    }).join("");
    return '<p class="sub">' + G.monsters.length + "/" + S.D.housing + ' housed</p><div class="hscroll">' + recruit + '</div><div class="chiptabs">' + tabs.join("") + '</div><div class="stack">' + (list.map(monsterRow).join("") || '<p class="note">No monsters match.</p>') + "</div>";
  }

  /* ================= HUMANS ================= */
  function humanRow(h) {
    var def = C.HUMAN[h.occ], jb = h.job ? S.bld(h.job) : null, escaping = h.st === "escape";
    return '<div class="erow" data-act="open-ent" data-id="' + h.id + '"><div class="eport">' + Art.img("h_" + h.occ, 2) + "</div><div class=\"ebody\"><h4>" + esc(h.name) + "</h4><p>" + def.name + " &middot; " + rarTag(h.rar) + "</p>" +
      '<p class="sub2">' + (escaping ? '<span class="warnText">Fleeing!</span>' : jb ? "Working: " + C.BUILD[jb.type].name : "Idle") + "</p></div><span class=\"chev\">›</span></div>";
  }
  function humansTab() {
    var G = S.G, list = G.humans.slice().sort(function (a, b) { return b.rar - a.rar; });
    return '<p class="sub">' + list.filter(function (h) { return h.st !== "escape"; }).length + "/" + S.D.prisonCap + ' held &middot; eating ' + n1(S.D.eatH) + " food/min</p><div class=\"stack\">" + (list.map(humanRow).join("") || '<p class="note">No captives yet. Send a raid in Military.</p>') + "</div>";
  }

  /* ================= ENTITY DETAIL ================= */
  function itemRow(it, mid) {
    return '<div class="item-row"><span>' + it.name + " <b>+" + it.val + "</b> " + rarTag(it.rar) + '</span><button class="pbtn sm" data-act="equip" data-m="' + mid + '" data-i="' + it.id + '">Equip</button></div>';
  }
  function eqSlot(m, slot) {
    var it = m.eq[slot];
    if (!it) return '<div class="eqslot empty">No ' + slot + "</div>";
    return '<div class="eqslot"><span>' + it.name + " <b>+" + it.val + "</b></span><button class=\"pbtn sm dark\" data-act=\"unequip\" data-m=\"" + m.id + '" data-slot="' + slot + '">Remove</button></div>';
  }
  function entSheet(d) {
    var e = S.ent(d.id);
    if (!e) return { title: "Gone", html: "<p class=\"note\">This one is no longer around.</p>" };
    if (e.kind === "m") {
      var sp = C.SPECIES[e.sp], need = S.xpNeed(e.level);
      var items = S.G.items.filter(function (i) { return i.slot === "weapon"; }), armors = S.G.items.filter(function (i) { return i.slot === "armor"; });
      var skills = S.skills(e).map(function (s) { return "<li><b>" + s.name + "</b> " + s.desc + "</li>"; }).join("") || "<li>Unlocks skills at level 3 and 5.</li>";
      var canEvolve = S.G.research.done.evolution && e.level >= C.EVOLVE_LEVEL && !e.evolved;
      var jobBtns = Object.keys(C.BUILD).filter(function (k) { var def = C.BUILD[k]; return def.slots && (def.kind !== "human") && (S.D.cnt[k] || 0) > 0; }).map(function (k) {
        return S.G.buildings.filter(function (b) { return b.type === k; }).map(function (b) {
          var full = b.workers.length >= S.slots(b), here = e.job === b.id;
          return '<button class="pbtn sm ' + (here ? "go" : "") + '" data-act="assign" data-m="' + e.id + '" data-b="' + b.id + '"' + (full && !here ? " disabled" : "") + ">" + C.BUILD[k].name + (b.workers.length) + "/" + S.slots(b) + "</button>";
        }).join("");
      }).join("");
      return { title: e.name, html:
        '<div class="detail-head"><div class="port big">' + Art.img(e.sp, 4) + '</div><div><h3>' + esc(e.name) + " &middot; Lv" + e.level + "</h3><p>" + sp.name + (e.evolved ? " → " + C.EVOLVE[e.sp] : "") + " &middot; " + rarTag(e.rar) + " &middot; " + traitLine(e) + "</p>" +
        '<p class="sub2">XP ' + barPx(e.xp, need, "#f2b53c") + Math.floor(e.xp) + "/" + need + "</p></div></div>" +
        '<div class="statgrid"><span>HP <b>' + Math.round(S.stat(e, "hp") * e.hpf) + "/" + Math.round(S.stat(e, "hp")) + "</b></span><span>ATK <b>" + n1(S.stat(e, "atk")) + "</b></span><span>DEF <b>" + n1(S.stat(e, "def")) + '</b></span><span>Power <b>' + Math.round(S.power(e)) + "</b></span></div>" +
        '<h4 class="h4">Skills</h4><ul class="skl">' + skills + "</ul>" +
        '<h4 class="h4">Equipment</h4>' + eqSlot(e, "weapon") + eqSlot(e, "armor") +
        (items.length ? '<p class="sub2">Available weapons</p>' + items.map(function (i) { return itemRow(i, e.id); }).join("") : "") +
        (armors.length ? '<p class="sub2">Available armor</p>' + armors.map(function (i) { return itemRow(i, e.id); }).join("") : "") +
        '<h4 class="h4">Assign to work</h4><div class="hscroll2">' + (jobBtns || '<p class="note">Build a workplace first.</p>') + "</div>" +
        (e.job ? '<button class="pbtn dark" data-act="unassign" data-m="' + e.id + '">Unassign</button>' : "") +
        (canEvolve ? '<button class="pbtn go" data-act="evolve" data-m="' + e.id + '">Evolve into ' + C.EVOLVE[e.sp] + " (" + costRow(C.EVOLVE_COST) + ")</button>" : "") +
        (e.away ? "" : '<button class="pbtn danger" data-act="dismiss" data-m="' + e.id + '">Dismiss</button>') };
    }
    var def = C.HUMAN[e.occ];
    var hjobs = Object.keys(C.BUILD).filter(function (k) { return C.BUILD[k].slots && C.BUILD[k].kind !== "monster"; }).reduce(function (a, k) { return a.concat(S.G.buildings.filter(function (b) { return b.type === k; })); }, []).map(function (b) {
      var full = b.workers.length >= S.slots(b), here = e.job === b.id;
      return '<button class="pbtn sm ' + (here ? "go" : "") + '" data-act="assign" data-m="' + e.id + '" data-b="' + b.id + '"' + (full && !here ? " disabled" : "") + ">" + C.BUILD[b.type].name + " " + b.workers.length + "/" + S.slots(b) + "</button>";
    }).join("");
    return { title: e.name, html:
      '<div class="detail-head"><div class="port big">' + Art.img("h_" + e.occ, 4) + '</div><div><h3>' + esc(e.name) + "</h3><p>" + def.name + " &middot; " + rarTag(e.rar) + '</p><p class="sub2">Productivity ' + n1(e.prod) + "x &middot; HP " + e.hp + "</p></div></div>" +
      (e.st === "escape" ? '<p class="note warn">Fleeing toward the gate!</p>' : "") +
      '<h4 class="h4">Assign to work</h4><div class="hscroll2">' + (hjobs || '<p class="note">Build a human facility first.</p>') + "</div>" +
      (e.job ? '<button class="pbtn dark" data-act="unassign" data-m="' + e.id + '">Unassign</button>' : "") };
  }

  /* ================= BUILDING DETAIL ================= */
  function bldSheet(d) {
    var b = S.bld(d.id); if (!b) return { title: "Gone", html: "<p class=\"note\">That building is gone.</p>" };
    var def = C.BUILD[b.type], cap = S.levelCap(b), upCost = b.level < cap ? S.upCost(b) : null;
    var rate = def.out ? S.bRate(b, 1) : null;
    var html = '<div class="detail-head"><img class="px" src="' + Art.thumb(b.type, b.level, 72) + '" width="72" height="72"><div><h3>' + def.name + " Lv" + b.level + "</h3><p>" + def.desc + "</p></div></div>";
    if (rate) html += '<div class="statgrid">' + Object.keys(rate).map(function (k) { return "<span>" + C.RES_NAME[k] + " <b>+" + n1(rate[k]) + "/m</b></span>"; }).join("") + "</div>";
    if (def.slots) {
      var slots = S.slots(b), workers = b.workers.map(S.ent).filter(Boolean);
      html += '<h4 class="h4">Workers (' + workers.length + "/" + slots + ')</h4><div class="stack">' + (workers.map(function (e) { return '<div class="erow sm" data-act="open-ent" data-id="' + e.id + '">' + Art.img(e.kind === "m" ? e.sp : "h_" + e.occ, 2) + "<span>" + esc(e.name) + '</span><button class="pbtn sm dark" data-act="unassign" data-m="' + e.id + '">Remove</button></div>'; }).join("") || '<p class="note">Assign monsters or humans from their own panel.</p>') + "</div>";
    }
    if (b.type === "castle") {
      var cu = C.CASTLE_UP[b.level];
      if (cu) html += '<h4 class="h4">Next level unlocks</h4><p class="note">' + cu.unlocks + "</p><p class=\"sub2\">Needs " + cu.pop + " monsters" + (cu.need.length ? " and a " + cu.need.map(function (n) { return C.BUILD[n].name; }).join(", ") : "") + "</p>";
    }
    if (b.type === "blacksmith") {
      html += '<h4 class="h4">Craft equipment</h4><p class="sub2">Tier unlocked: ' + S.maxTier("weapon") + "</p>";
      for (var t = 1; t <= 5; t++) {
        var locked = t > S.maxTier("weapon"), cost = C.CRAFT_COST(t);
        html += '<div class="craftrow"><span>Tier ' + t + "</span>" + costRow(cost) + '<button class="pbtn sm" data-act="craft" data-slot="weapon" data-t="' + t + '"' + (locked ? " disabled" : "") + '>Weapon</button><button class="pbtn sm" data-act="craft" data-slot="armor" data-t="' + t + '"' + (locked ? " disabled" : "") + ">Armor</button></div>";
      }
    }
    if (b.type === "trading") {
      html += '<h4 class="h4">Trade (lot of ' + C.TRADE_LOT + ')</h4>' + C.RES.filter(function (r) { return r !== "gold"; }).map(function (r) {
        var p = Math.round(S.price(r) * C.TRADE_LOT);
        return '<div class="craftrow"><span>' + Art.img("i_" + r, 1) + C.RES_NAME[r] + " ~" + p + "g</span><button class=\"pbtn sm\" data-act=\"trade\" data-res=\"" + r + '" data-side="buy">Buy</button><button class="pbtn sm dark" data-act="trade" data-res="' + r + '" data-side="sell">Sell</button></div>';
      }).join("");
    }
    if (upCost) html += '<h4 class="h4">Upgrade to Lv' + (b.level + 1) + "</h4>" + costRow(upCost) + '<button class="pbtn go" data-act="upgrade" data-b="' + b.id + '">Upgrade</button>';
    else html += '<p class="note">Max level' + (b.type !== "castle" ? " for this castle tier" : "") + ".</p>";
    if (!def.fixed) {
      html += '<div class="rowgap"><button class="pbtn dark" data-act="move-bld" data-b="' + b.id + '">Move</button><button class="pbtn danger" data-act="remove-bld" data-b="' + b.id + '">Remove</button></div>';
    }
    return { title: def.name, html: html };
  }

  /* ================= MILITARY / RAID ================= */
  function raidSheet(d) {
    if (d.terr) return raidDetail(d.terr);
    var html = C.TERR.map(function (t) {
      var unlocked = Raid.unlocked(t);
      return '<div class="terrcard' + (unlocked ? "" : " locked") + '" data-act="raid-open" data-t="' + t.id + '"><img class="px" src="' + Art.thumb("prison", 1, 44) + '" width="44" height="44"><div class="bc-info"><h4>' + t.name + ' <span class="tier">Tier ' + t.tier + "</span></h4><p>" + t.desc + "</p>" +
        (unlocked ? '<p class="sub2">Strength ~' + t.str + " &middot; travel " + t.travel + "s</p>" : '<p class="note warn">Needs castle level ' + t.castle + (t.gate ? " and a " + C.BUILD[t.gate].name : "") + "</p>") + "</div></div>";
    }).join("");
    var active = S.G.exps.length ? '<h4 class="h4">Squads out</h4>' + S.G.exps.map(function (e) {
      var t = Raid.terrFor(e.terr);
      return '<div class="craftrow"><span>' + t.name + "</span><span>" + Math.ceil(e.left) + "s left</span><button class=\"pbtn sm dark\" data-act=\"recall\" data-e=\"" + e.id + '">Recall</button></div>';
    }).join("") : "";
    var reports = S.G.reports.length ? '<h4 class="h4">Recent reports</h4><div class="stack">' + S.G.reports.slice(0, 6).map(function (r) {
      return '<div class="erow sm ' + (r.win ? "" : "lose") + '" data-act="report-open" data-r="' + r.id + '"><span>' + (r.win ? "✔" : "✖") + " " + r.terr + "</span><span class=\"chev\">›</span></div>";
    }).join("") + "</div>" : "";
    return { title: "Military", html: '<p class="sub">Squad limit: ' + S.D.squadCap + "</p>" + active + '<h4 class="h4">Territories</h4><div class="stack">' + html + "</div>" + reports };
  }
  function raidDetail(id) {
    var t = Raid.terrFor(id), unlocked = Raid.unlocked(t);
    if (!unlocked) return { title: t.name, html: '<p class="note warn">Needs castle level ' + t.castle + (t.gate ? " and a " + C.BUILD[t.gate].name : "") + '.</p><button class="pbtn dark" data-act="raid-back">Back</button>' };
    var picks = raidPick[id] || (raidPick[id] = []);
    var avail = S.G.monsters.filter(function (m) { return !m.away; }).sort(function (a, b) { return S.power(b) - S.power(a); });
    var power = Raid.squadPower(picks), chance = Raid.winChance(power, t), pc = Math.round(chance * 100);
    var odds = picks.length ? '<p class="odds ' + (pc >= 70 ? "hi" : pc >= 40 ? "mid" : "lo") + '">Win chance ~' + pc + "%" + (pc < 40 ? " — risky!" : "") + "</p>" : "";
    var rows = avail.map(function (m) {
      var on = picks.indexOf(m.id) >= 0;
      return '<label class="pickrow"><input type="checkbox" data-act="raid-pick" data-m="' + m.id + '"' + (on ? " checked" : "") + (!on && picks.length >= S.D.squadCap ? " disabled" : "") + '>' + Art.img(m.sp, 2) + '<span>' + esc(m.name) + " Lv" + m.level + " (" + Math.round(S.power(m)) + " pwr)</span></label>";
    }).join("") || '<p class="note">No monsters available.</p>';
    return { title: t.name, html: '<p>' + t.desc + '</p><p class="sub2">Enemy strength ~' + t.str + " &middot; travel " + t.travel + "s &middot; up to " + S.D.squadCap + " monsters</p>" +
      '<h4 class="h4">Rewards</h4><div class="costs">' + Object.keys(t.rew).map(function (k) { return '<span class="cost">' + Art.img("i_" + k, 1) + t.rew[k][0] + "-" + t.rew[k][1] + "</span>"; }).join("") + "</div>" +
      '<h4 class="h4">Pick your squad (' + picks.length + "/" + S.D.squadCap + ')</h4><div class="stack">' + rows + '</div>' +
      '<p class="sub2">Squad power: ' + Math.round(power) + " vs strength " + t.str + "</p>" + odds +
      '<button class="pbtn dark" data-act="raid-auto" data-t="' + id + '">Auto-pick strongest</button>' +
      '<button class="pbtn go" data-act="raid-send" data-t="' + id + '"' + (picks.length ? "" : " disabled") + '>Send squad</button><button class="pbtn dark" data-act="raid-back">Back</button>' };
  }
  function reportSheet(d) {
    var r = S.G.reports.filter(function (x) { return x.id === d.r; })[0];
    if (!r) return { title: "Report", html: "<p class=\"note\">Report not found.</p>" };
    var rew = Object.keys(r.rewards).filter(function (k) { return k !== "_item"; }).map(function (k) { return '<span class="cost">' + Art.img("i_" + k, 1) + "+" + r.rewards[k] + "</span>"; }).join("");
    return { title: (r.win ? "Victory: " : "Defeat: ") + r.terr, html:
      '<div class="statgrid">' + r.squad.map(function (s) { return "<span>" + esc(s.name) + " <b>" + s.hp + "% HP</b></span>"; }).join("") + "</div>" +
      (r.win ? '<h4 class="h4">Loot</h4><div class="costs">' + rew + "</div>" + (r.rewards._item ? "<p class=\"sub2\">Found: " + r.rewards._item + "</p>" : "") : '<p class="note warn">The squad was beaten back.</p>') +
      (r.captives.length ? '<h4 class="h4">Captured</h4><ul class="skl">' + r.captives.map(function (c) { return "<li>" + esc(c.name) + " — " + c.occ + " (" + C.RARITY[c.rar].name + ")</li>"; }).join("") + "</ul>" : "") +
      (r.casualties.length ? '<p class="note warn">Lost: ' + r.casualties.join(", ") + "</p>" : "") };
  }

  /* ================= RESEARCH ================= */
  function researchTab() {
    var branches = {};
    C.RESEARCH.forEach(function (r) { (branches[r.branch] = branches[r.branch] || []).push(r); });
    var active = S.G.research.active;
    var activeHtml = active ? (function () { var r = C.RESEARCH.filter(function (x) { return x.id === active.id; })[0]; return '<div class="activeres"><b>' + r.name + "</b>" + barPx(active.total - active.left, active.total, "#f2b53c") + Math.ceil(active.left) + "s left</div>"; })() : "";
    var html = Object.keys(branches).map(function (br) {
      return '<h4 class="h4">' + br + '</h4><div class="stack">' + branches[br].map(function (r) {
        var why = S.canResearch(r), done = why === "done";
        return '<div class="bcard2' + (done ? " done2" : "") + '"><div class="bc-info"><h4>' + r.name + (done ? " ✓" : "") + '</h4><p>' + r.desc + "</p></div>" +
          (done ? "" : why && why !== "Busy" ? '<p class="note warn">' + why + "</p>" : costRow(r.cost) + '<p class="sub2">' + r.time + "s</p>") +
          (done || why === "Busy" || (why && why !== "Busy") ? "" : '<button class="pbtn go" data-act="research" data-id="' + r.id + '"' + (!S.canAfford(r.cost) ? " disabled" : "") + ">Research</button>") + "</div>";
      }).join("") + "</div>";
    }).join("");
    return { title: "Research", html: activeHtml + html };
  }

  /* ================= QUESTS FULL ================= */
  function questsTab() {
    var rows = C.QUESTS.map(function (q) {
      var done = S.G.quests[q.id], p = S.qProgress(q), ready = !done && p >= q.goal;
      return '<div class="bcard2' + (done ? " done2" : "") + '"><div class="bc-info"><h4>' + q.title + (done ? " ✓" : "") + '</h4><p>' + q.desc + "</p><p class=\"sub2\">" + p + "/" + q.goal + "</p></div>" +
        (done ? "" : costRow(q.reward)) + (ready ? '<button class="pbtn go" data-act="claim" data-q="' + q.id + '">Claim</button>' : "") + "</div>";
    }).join("");
    return { title: "Quests", html: '<div class="stack">' + rows + "</div>" };
  }

  /* ================= SETTINGS ================= */
  function settingsTab() {
    return { title: "Settings", html:
      '<p class="sub">The game saves by itself every 15 seconds, and whenever you leave the page.</p>' +
      '<div class="stack"><button class="pbtn go" data-act="save-now">Save now</button>' +
      '<button class="pbtn dark" data-act="export-save">Copy save to clipboard</button>' +
      '<button class="pbtn dark" data-act="import-save">Load save from clipboard</button>' +
      '<button class="pbtn danger" data-act="wipe">Start a new game</button></div>' };
  }

  /* ---------- registry ---------- */
  var SHEETS = {
    build: function (d) { return { title: "Build", html: buildTab(d.cat) }; },
    monsters: function (d) { return { title: "Monsters", html: monstersTab(d.filter) }; },
    humans: function () { return { title: "Humans", html: humansTab() }; },
    military: function (d) { curTerrId = d.terr || null; return raidSheet(d); },
    report: reportSheet, research: researchTab, quests: questsTab, settings: settingsTab,
    ent: entSheet, bld: bldSheet
  };

  UI.openTab = function (tab, data) { openSheet(tab, data || {}); };
  UI.openEnt = function (id) { openSheet("ent", { id: id }); Rd.setSelection({ type: "ent", id: id }); };
  UI.openBld = function (id) { openSheet("bld", { id: id }); Rd.setSelection({ type: "bld", id: id }); };
  UI.openCamp = function (id) { openSheet("military", { terr: id }); };
  UI.openReport = function (id) { openSheet("report", { r: id }); };

  UI.togglePick = function (mid) {
    if (!curTerrId) return;
    mid = parseInt(mid, 10);
    var arr = raidPick[curTerrId] = raidPick[curTerrId] || [];
    var i = arr.indexOf(mid);
    if (i >= 0) arr.splice(i, 1); else if (arr.length < S.D.squadCap) arr.push(mid);
    renderSheet();
  };
  UI.autoPick = function (terrId) {
    var cap = S.D.squadCap, avail = S.G.monsters.filter(function (m) { return !m.away; }).sort(function (a, b) { return S.power(b) - S.power(a); });
    raidPick[terrId] = avail.slice(0, cap).map(function (m) { return m.id; });
    renderSheet();
  };
  UI.sendRaid = function (terrId) {
    var picks = (raidPick[terrId] || []).slice();
    var r = Raid.send(picks, terrId);
    if (r.ok) raidPick[terrId] = [];
    return r;
  };

  /* ---------- modal (tutorial / offline / confirm) ---------- */
  UI.modal = function (html) { var m = $("modal"); m.innerHTML = html; m.hidden = false; };
  UI.closeModal = function () { $("modal").hidden = true; };

  UI.tutorialModal = function (step, total, title, text) {
    UI.modal('<div class="modalcard"><div class="kicker">Tutorial ' + (step + 1) + "/" + total + '</div><h2>' + esc(title) + "</h2><p>" + esc(text) + '</p><button class="pbtn go" data-act="tut-next">' + (step + 1 < total ? "Next" : "Start playing") + "</button></div>");
  };

  UI.offlineModal = function (rep) {
    var hrs = Math.floor(rep.seconds / 3600), mins = Math.round((rep.seconds % 3600) / 60);
    var gained = C.RES.filter(function (k) { return (rep.gross[k] || 0) > 0.5; }).map(function (k) { return '<span class="cost">' + Art.img("i_" + k, 1) + "+" + Math.floor(rep.gross[k]) + "</span>"; }).join("");
    var ev = rep.events.length ? "<ul class=\"skl\">" + rep.events.map(function (e) { return "<li>" + esc(e) + "</li>"; }).join("") + (rep.moreEvents ? "<li>+" + rep.moreEvents + " more</li>" : "") + "</ul>" : '<p class="note">A quiet stretch.</p>';
    UI.modal('<div class="modalcard"><div class="kicker">While you were away</div><h2>' + hrs + "h " + mins + "m passed</h2><div class=\"costs\">" + (gained || '<span class="note">Nothing produced.</span>') + "</div>" +
      (rep.monsters ? '<p class="sub2">+' + rep.monsters + " monster(s) born</p>" : "") + (rep.escapes ? '<p class="note warn">' + rep.escapes + " captive(s) escaped</p>" : "") +
      '<h4 class="h4">What happened</h4>' + ev + '<button class="pbtn go" data-act="close-modal">Continue</button></div>');
  };

  UI.confirm = function (text, actHtml) {
    UI.modal('<div class="modalcard"><h2>Are you sure?</h2><p>' + esc(text) + '</p><div class="rowgap">' + actHtml + '<button class="pbtn dark" data-act="close-modal">Cancel</button></div></div>');
  };

  UI.placeBar = function (p) {
    var bar = $("placeBar");
    if (!p) { if (!bar.hidden) bar.hidden = true; return; }
    bar.hidden = false;
    var txt = C.BUILD[p.type].name + (p.valid === false ? " — " + (p.reason || "Can't place here") : ""), lab = $("placeLabel");
    if (lab.textContent !== txt) { lab.textContent = txt; lab.className = p.valid === false ? "warnText" : ""; }
    var ok = $("placeOk"); if (ok) ok.disabled = p.valid === false;
  };

  UI.refreshAll = function () { UI.hud(); UI.quests(); UI.refreshSheet(); };
})();
