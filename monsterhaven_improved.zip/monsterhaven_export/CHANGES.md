# Monsterhaven – what changed

## Bugs fixed
- Tapping any button/sheet also "tapped the map" underneath (closing sheets, selecting monsters). Map input now ignores touches that start on the UI.
- Recalled raid squads never came home (monsters stuck "away" forever). They now return; old saves self-heal on load.
- Raid timers ran per frame, not per second (wrong on 120Hz screens, ignored game speed). Now driven by game time.
- "Start a new game" didn't work: the unload autosave re-saved the old kingdom. Fixed.
- HUD/quest/sheet markup was rewritten every frame, which could swallow taps. Now only updates when content changes.
- index.html had no doctype/viewport tag (phones rendered it zoomed out).
- Placement: no hover preview on desktop; on phones a tap built instantly with no chance to adjust.
- Closing the sheet during placement left the place bar stuck on screen.

## Improvements
- Placement: mouse hover preview + click; touch = tap to position, then Place/Rotate/Cancel.
- Raid screen shows win chance and an "Auto-pick strongest" button; toast when a squad reports back.
- Catch-up progress when you return to a backgrounded tab (not only on page load).
- Day counter + night tint (config.DAY_LEN was unused).
- All six resources visible in the HUD; compact controls.
- Finished quests show "Claim!" in the tracker; one tap claims.
- Settings (gear): save now, copy/load save via clipboard, new game.
